from pathlib import Path
import hashlib,json,re,difflib
R=Path('/workspace/scratch/5e06a74e5f65/restart-20261012T2033');E=R/'checkpoint-format';B=E/'before';F=E/'after-gofmt';O=E/'overlay';W=R/'gosqlite';sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((E/'initial-manifest.json').read_text());files=m['files']
# Text lexical comparison, never a Go parser/scanner/compiler/test/native call.
lex=re.compile(r'//[^\n]*|/\*.*?\*/|"(?:[^"\\]|\\.)*"|`[^`]*`|\'(?:[^\'\\]|\\.)*\'|[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9.]*|<<=|>>=|&\^=|\.\.\.|:=|==|!=|<=|>=|&&|\|\||<-|\+\+|--|<<|>>|&\^|[+*/%&|^\-]=|[^\s;]',re.S)
def tokenmatches(s):return [x for x in lex.finditer(s) if not x.group().startswith(('//','/*'))]
def tokens(s):return [x.group() for x in tokenmatches(s)]
def normalized(s):
 # gofmt sorts this one previously non-sorted import declaration. Compare the
 # complete import multiset exactly, then normalize only its order for proof.
 match=re.search(r'(?ms)^import \(\n(.*?)^\)',s)
 if match:
  lines=match[1].splitlines();s=s[:match.start(1)]+'\n'.join(sorted(lines))+'\n'+s[match.end(1):]
 return tokens(s)
proof=[]
for p in files:
 a=(B/p).read_bytes();z=(O/p).read_bytes();assert a==z if not p.endswith('.go') else normalized(a.decode())==normalized(z.decode()),p
 ca=[x.group() for x in lex.finditer(a.decode()) if x.group().startswith(('//','/*'))];cz=[x.group() for x in lex.finditer(z.decode()) if x.group().startswith(('//','/*'))];assert ca==cz,p
 proof.append({'path':p,'reviewed_sha256':sha(a),'formatted_sha256':sha(z),'changed':a!=z,'noncomment_nonseparator_token_spelling_equal_after_exact_import_multiset_normalization':True,'all_comment_bytes_preserved':True,'import_sort_only':p=='internal/testkit/checkpointrestart/contract.go'})
(E/'format-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
strpat=r'"(?:[^"\\]|\\.)*"';lit=r'(?:`[^`]*`|'+strpat+r')'
def decode(x):return x[1:-1] if x.startswith('`') else json.loads(x)
def constants(s):return {k:json.loads(v) for k,v in re.findall(r'^const ((?:checkpoint|rekey)Guard\w+) = ('+strpat+r')',s,re.M)}
def source(p):return (O/p).read_text() if (O/p).exists() else (W/p).read_text()
def parse_map(s,name):
 match=re.search(r'(var '+name+r' = map\[string\]string\{\n)(.*?)(\n\})',s,re.S);assert match,name
 entries=re.findall(r'^\s*('+strpat+r'):\s*('+strpat+r'),$',match[2],re.M)
 return match,{json.loads(k):json.loads(v) for k,v in entries}
def sync_snapshots(s,name,expected_count,allowed_paths=None):
 match,entries=parse_map(s,name);assert len(entries)==expected_count,(name,len(entries));records=[]
 def sub(x):
  p=json.loads(x[2]);old=json.loads(x[4]);new=source(p)
  assert old==((B/p).read_text() if (B/p).exists() else (W/p).read_text()),(name,p,'snapshot input drift')
  if allowed_paths is not None and p not in allowed_paths:assert old==new,p
  records.append({'path':p,'before_sha256':sha(old.encode()),'after_sha256':sha(new.encode()),'changed':old!=new,'exact_full_source':True})
  return x[1]+x[2]+x[3]+json.dumps(new,ensure_ascii=True)+x[5]
 block=re.sub(r'(^\s*)('+strpat+r')(:\s*)('+strpat+r')(,)$',sub,match[2],flags=re.M)
 return s[:match.start(2)]+block+s[match.end(2):],records
def release(s,mapname,prefix,count):
 consts=constants(s);start=s.index('var '+mapname+' = map[string]string{');end=s.index('\n}',start);records=[]
 def sub(x):
  key=x[2];p=consts[key];h=sha(source(p).encode());records.append({'key':key,'path':p,'sha256':h})
  return x[1]+key+x[3]+'"'+h+'"'+x[4]
 block=re.sub(r'(^\s*)('+prefix+r'\w+)(:\s*)'+prefix+r'Hold(,)$',sub,s[start:end],flags=re.M);assert len(records)==count,(mapname,len(records))
 return s[:start]+block+s[end:],records
# First release the reviewed R5 shared identities, leaving all other R5 pins,
# bodies, inventories and mutant obligations unchanged.
rp='internal/testscope/rekey_interruption.go';r=(O/rp).read_text();r_before=r
shared={'internal/encstore/publish.go','internal/testscope/main.go','internal/testscope/oracle_startup.go'}
r,rshapes=sync_snapshots(r,'rekeyGuardShapes',9,shared);r,rpins=release(r,'rekeyGuardPins','rekeyGuard',3);assert {v['path'] for v in rpins}==shared
(O/rp).write_text(r)
(E/'02-r5-shared-release.diff').write_text(''.join(difflib.unified_diff(r_before.splitlines(True),r.splitlines(True),'gofmt/'+rp,'r5-released/'+rp)))
(E/'r5-release-stage.json').write_text(json.dumps({'order':1,'guard_sha256':sha(r.encode()),'pins':rpins,'nine_fullfile_snapshots':rshapes,'other_six_pins_unchanged':True},indent=2)+'\n')
# Then bind exactly 17 source templates and 18 checkpoint pins to the final
# approved formatted files, never a blanket hash refresh.
cp='internal/testscope/checkpoint_restart.go';c=(O/cp).read_text();c_before=c
c,cshapes=sync_snapshots(c,'checkpointGuardTemplates',17);c,cpins=release(c,'checkpointGuardPins','checkpointGuard',18);(O/cp).write_text(c)
(E/'03-checkpoint-release.diff').write_text(''.join(difflib.unified_diff(c_before.splitlines(True),c.splitlines(True),'gofmt/'+cp,'checkpoint-released/'+cp)))
(E/'checkpoint-release-stage.json').write_text(json.dumps({'order':2,'r5_release_stage_sha256':sha((E/'r5-release-stage.json').read_bytes()),'pins':cpins,'seventeen_fullfile_snapshots':cshapes},indent=2)+'\n')
# Convert the exact 11 stale source anchors to their unique formatted token
# span. Preserve every mutant replacement byte, identity, root and call order.
tp='internal/testscope/checkpoint_restart_test.go';t=(O/tp).read_text();t_before=t;consts=constants(c)
pat=re.compile(r'checkpointGuardMutant\(t, (checkpointGuard\w+),\s*('+lit+r'|checkpointGuard\w+),\s*('+lit+r')\)',re.S)
anchors=[];changes=[]
for match in pat.finditer(t):
 key,oldexpr,newexpr=match.groups();p=consts[key];old=consts[oldexpr] if oldexpr.startswith('checkpointGuard') else decode(oldexpr);new=decode(newexpr);a=(B/p).read_text();z=source(p);assert old in a,(p,old)
 formatted=old
 if old not in z:
  assert oldexpr.startswith('`'),oldexpr
  needle=tokens(old);hay=tokenmatches(z);values=[x.group() for x in hay];indices=[i for i in range(len(values)-len(needle)+1) if values[i:i+len(needle)]==needle];assert len(indices)==1,(p,old,len(indices))
  i=indices[0];formatted=z[hay[i].start():hay[i+len(needle)-1].end()];assert tokens(formatted)==needle
  changes.append((match.start(2),match.end(2),'`'+formatted+'`'))
 anchors.append({'test_path':tp,'source_path':p,'from_before':old,'from_final':formatted,'to_unchanged':new,'from_before_count':a.count(old),'from_final_count':z.count(formatted),'token_spelling_invariant':True,'adapted':formatted!=old})
assert len(anchors)==73 and len(changes)==11,(len(anchors),len(changes))
for start,end,replacement in reversed(changes):t=t[:start]+replacement+t[end:]
(O/tp).write_text(t)
(E/'04-anchor-adaptations.diff').write_text(''.join(difflib.unified_diff(t_before.splitlines(True),t.splitlines(True),'gofmt/'+tp,'anchor-synced/'+tp)))
(E/'checkpoint-mutation-anchor-proof.json').write_text(json.dumps(anchors,indent=2)+'\n')
# R5 direct literal mutations remain present, including the 2 checkpoint neighbors.
rc=constants(r);rt=(O/'internal/testscope/rekey_interruption_test.go').read_text();ranchors=[]
for key,oldexpr,newexpr in re.findall(r'rekeyGuardMutant\(t,\s*(rekeyGuard\w+),\s*('+lit+r'|rekeyGuard\w+),\s*('+lit+r')\)',rt,re.S):
 old=rc[oldexpr] if oldexpr.startswith('rekeyGuard') else decode(oldexpr);p=rc[key];assert old in source(p),(p,old);ranchors.append({'path':p,'from':old,'to':decode(newexpr),'count':source(p).count(old)})
assert len(ranchors)==47,len(ranchors)
(E/'rekey-mutation-anchor-proof.json').write_text(json.dumps(ranchors,indent=2)+'\n')
# All pins and snapshots exactly bind their final full source, with the 6 R5
# nonshared entries preserved byte for byte. Neither guard pins itself.
for raw,mapname,prefix,count in [(r,'rekeyGuardPins','rekeyGuard',9),(c,'checkpointGuardPins','checkpointGuard',18)]:
 cs=constants(raw);block=raw.split('var '+mapname+' = map[string]string{',1)[1].split('\n}',1)[0];entries=re.findall(r'^\s*('+prefix+r'\w+):\s*"([a-f0-9]{64})",$',block,re.M);assert len(entries)==count
 for key,h in entries:assert h==sha(source(cs[key]).encode()),key
for raw,name,count in [(r,'rekeyGuardShapes',9),(c,'checkpointGuardTemplates',17)]:
 _,entries=parse_map(raw,name);assert len(entries)==count
 for p,rawsource in entries.items():assert rawsource==source(p),p
# Preserve independently frozen R5 body literals unchanged.
for name in ['rekeyGuardCriticalBodies','rekeyGuardBridgeBodies']:
 a,ae=parse_map((B/rp).read_text(),name);z,ze=parse_map(r,name);assert ae==ze,name
# Main's ordinary inspectSource body remains exactly the previously reviewed body.
oldmain=(W/'internal/testscope/main.go').read_bytes();main=(O/'internal/testscope/main.go').read_bytes()
def ordinary(s):
 f=s[s.index(b'func inspectSource('):s.index(b'\nfunc main()')].rstrip();return f
assert ordinary(oldmain)==ordinary(main) and sha(ordinary(main))=='98341345e43f39b39dbc78eaf49a916a0701f3d7f2f383d4949b9a3ed439d199'
(E/'inspectSource-body-proof.json').write_text(json.dumps({'before_whole_main_sha256':sha(oldmain),'final_whole_main_sha256':sha(main),'ordinary_function_sha256':sha(ordinary(main)),'ordinary_function_byte_identical':True},indent=2)+'\n')
oldh=sha(oldmain);newh=sha(main);owners=[('internal/testscope/wal_tail_publication.go','walPublicationFrozenSources'),('internal/testscope/encryption_upgrade_manual.go','formatUpgradePins'),('internal/testscope/encrypted_root_negative.go','encryptedRootPins'),('internal/testscope/rollback_fault_test.go','reviewedMainSHA256'),('internal/testscope/rollback_fault_sql_test.go','reviewedMainSHA256'),('internal/testscope/rollback_restart_test.go','reviewedWholeMain')];plans=[]
for p,label in owners:
 b=(W/p).read_bytes();assert b.count(oldh.encode())==1,(p,b.count(oldh.encode()));assert newh.encode() not in b;pinnedlines=[(i,line) for i,line in enumerate(b.decode().splitlines(),1) if oldh in line];assert len(pinnedlines)==1
 plans.append({'path':p,'owner':label,'w_source_sha256_at_plan':sha(b),'replace_once_old':oldh,'replace_once_new':newh,'line':pinnedlines[0][0],'exact_current_line':pinnedlines[0][1],'instruction':'Replace this single hash literal in the current W file, preserving every other byte. Do not copy an old file or full snapshot.'})
(E/'legacy-main-pin-plan.json').write_text(json.dumps({'status':'NOT_APPLIED; lead owns six existing pins','ordinary_body_pin_unchanged':'98341345e43f39b39dbc78eaf49a916a0701f3d7f2f383d4949b9a3ed439d199','owners':plans},indent=2)+'\n')
# Confirm no worker touched the W paths; publication may change docs/evidence only.
for p,d in files.items():
 b=(W/p).read_bytes() if (W/p).exists() else None;assert (sha(b) if b is not None else None)==d['w_before_sha256'],p
for d in plans:assert sha((W/d['path']).read_bytes())==d['w_source_sha256_at_plan'],d['path']
print(json.dumps({'status':'EXACT_SOURCE_SYNC_COMPLETE','r5_pins_released_first':3,'checkpoint_pins':18,'snapshots_verified':26,'checkpoint_anchors':73,'format_anchor_adaptations':11,'rekey_anchors':47,'main_sha256':newh,'six_legacy_main_pins':'NOT_APPLIED','W_unchanged':True}))
