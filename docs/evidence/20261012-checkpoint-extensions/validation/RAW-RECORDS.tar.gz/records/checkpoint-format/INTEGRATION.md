# Final checkpoint R3/R4 format-only integration handoff

Status: approved source formatting and narrowly owned pin/snapshot synchronization complete. No W files changed. No Go compiler, Go test, Go source scanner/AST runner, native process, database fixture, reopen, or physical experiment was executed. The only Go executable run was the pinned official gofmt, once, on 23 files in this small overlay under the exclusive go-queue.lock, after the prior validation's recorded 23:04:54 UTC terminal PASS. Workspace and /tmp remained above the required resource floors.

## Exact deliverables

- `overlay/`: exactly the 24 reviewed facility/guard paths, not a checkout.
- `before/`: all 24 exact reviewed preformat input files, unchanged.
- `after-gofmt/`: all 23 exact formatter outputs, preserved before literal synchronization.
- `FINAL-MANIFEST.json`: final source SHA-256/lengths, reviewed input hashes, baseline W hashes and evidence identities.
- `changed-paths.txt`: exact integration path list.
- `FINAL-INTEGRATION.patch`: reviewed changes against the current source baseline recorded in the manifest; adds 15 paths and replaces 9 paths.
- `FINAL-FORMAT-SYNC.diff` and numbered diffs: complete separation of gofmt, R5 release, checkpoint release and anchor-only adaptations.
- `legacy-main-pin-plan.json`: six current-W one-literal updates for the lead, not applied here.
- `FINITE-PLANNED-TESTS.json`: exact 8 new guard, 30 affected old guard, 12 pure model and 3 healthy-default test root names; all NOT_RUN. The 3 manual native roots remain explicitly NOT_RUN.

## Formatting and finite identity proof

Official gofmt SHA-256: 5583dbb3339147fee7cdb067eb3cd4a50015b48c27084377f49d93833aa4ad77.

Fourteen of the 23 Go files changed. Text checks confirm identical noncomment/nonseparator token spelling, with the one exact import multiset sorted in contract.go (encoding/hex before encoding/json), and every comment preserved byte for byte. These are Python text comparisons, not Go parser or AST execution. The original fixed ten cases, three profiles, 315 rows, seven seams, twelve pure roots and three native roots remain unchanged.

R5's three shared publish/main/oracle pins were released first, with all nine full-file snapshots verified. Those nine snapshots already equal their final sources, so none required changing. The six other R5 pins and all independently frozen critical-body literals were preserved.

Then all 18 checkpoint pins were released and 17 full-file templates verified against final source. Nine of those template values needed formatting synchronization. Both hold constants remain available for negative tests; no gate was weakened or globally bypassed.

All 73 checkpoint mutation source anchors are present. Eleven stale anchors were adapted only to the corresponding unique formatted token spans. Every mutation replacement remains byte-identical, and reverting those 11 source-anchor literals reconstructs the exact formatter output. All 47 direct R5 mutation anchors remain present, including the approved checkpoint-neighbor and earlier model-boundary regressions. Guard implementation bytes outside the explicitly verified map values equal their post-gofmt versions.

## Apply precisely, preserving the newer R2 work

1. Verify FINAL-MANIFEST.json against all 24 files in overlay, and verify each current W path equals its recorded baseline_sha256 (or remains absent for an add). Stop and merge deliberately if any source differs. Do not copy an old checkout or old rollback tests.
2. Copy/apply only those 24 paths. The reviewed readonly and rekey test replacements were checked against their current W baselines, including the existing R2 boundary regression retained in the R5 test. No legacy rollback test is part of this overlay.
3. In the CURRENT W versions of the six files listed in legacy-main-pin-plan.json, replace exactly one old hash literal with the final reviewed main hash. Verify the file's current hash against w_source_sha256_at_plan first, and preserve every other byte. These are wal_tail_publication.go, encryption_upgrade_manual.go, encrypted_root_negative.go, rollback_fault_test.go, rollback_fault_sql_test.go and rollback_restart_test.go, all under internal/testscope/.
4. Old whole-main hash: 1d9f41ed857bf64a3d2913f96fee3409a173f036df753efd81a7a9190ee2536a.
5. Final whole-main hash: 9d29dda532e851dd0fa2211473a5abb24309f798a849483c7efca09a7a3a058f.
6. Preserve the ordinary inspectSource function pin 98341345e43f39b39dbc78eaf49a916a0701f3d7f2f383d4949b9a3ed439d199. The exact 4,519-byte function, including its signature, is unchanged. This digest is the established full-function pin, despite some legacy names calling it a body pin.
7. Check resulting source identity and run only subsequently authorized finite validation. This preparation is not a compiler/test/native PASS. Linux manual qualification, if authorized later, must remain compile-only for sqlite; running a native test binary with -run=^$ is not a substitute.

## Minimal healthy-default selection

The source-only closure audit in healthy-default-closure-audit.json recommends exactly these existing roots with no manual tags:

- ./internal/pager: TestSharedWALSnapshotsPromotionAndCheckpoint covers the two shared copy/backfill no-ops.
- ./sqlite: TestNativeWALConnectionLifecycle covers the two exclusive copy/retirement no-ops through an explicit successful WALExclusive public checkpoint.
- ./sqlite: TestReviewEncryptionSharedLatestCheckpointMetadata covers the three encrypted publication no-ops through a refreshed encrypted shared checkpoint, then checks geometry and zero remaining WAL segments.

All use ordinary healthy committed fixtures, not fault injection or forced exits. The candidate TestSimilarityNativeTransactionsRebuildReopenCheckpoint only calls Checkpoint in its WALShared branch, so it would duplicate shared coverage and leave exclusive seams uncovered if used instead of TestNativeWALConnectionLifecycle. No new matrix or test was added.
