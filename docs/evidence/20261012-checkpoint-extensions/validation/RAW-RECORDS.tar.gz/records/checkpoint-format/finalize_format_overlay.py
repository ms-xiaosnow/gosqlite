from pathlib import Path
import re,json,hashlib,difflib,datetime
R=Path('/workspace/scratch/5e06a74e5f65/restart-20261012T2033');E=R/'checkpoint-format';B=E/'before';F=E/'after-gofmt';O=E/'overlay';W=R/'gosqlite';sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((E/'initial-manifest.json').read_text());files=m['files'];strpat=r'"(?:[^"\\]|\\.)*"';lit=r'(?:`[^`]*`|'+strpat+r')'
def normmaps(s,names):
 for name in names:
  match=re.search(r'(var '+name+r' = map\[string\]string\{\n)(.*?)(\n\})',s,re.S);assert match
  s=s[:match.start(2)]+'<EXPLICITLY_VERIFIED_MAP>'+s[match.end(2):]
 return s
for p,names in [('internal/testscope/rekey_interruption.go',['rekeyGuardPins','rekeyGuardShapes']),('internal/testscope/checkpoint_restart.go',['checkpointGuardPins','checkpointGuardTemplates'])]:
 assert normmaps((F/p).read_text(),names)==normmaps((O/p).read_text(),names),p
p='internal/testscope/checkpoint_restart_test.go';t=(O/p).read_text();a=(F/p).read_text();anchors=json.loads((E/'checkpoint-mutation-anchor-proof.json').read_text())
for d in anchors:
 if d['adapted']:
  new='`'+d['from_final']+'`';old='`'+d['from_before']+'`';assert t.count(new)==1,(new,t.count(new));t=t.replace(new,old,1)
assert t==a
for p in files:
 if p not in ['internal/testscope/checkpoint_restart_test.go','internal/testscope/checkpoint_restart.go','internal/testscope/rekey_interruption.go']:
  assert (O/p).read_bytes()==((F/p).read_bytes() if p.endswith('.go') else (B/p).read_bytes()),p
# Exact 3 healthy existing roots: 7 no-op seams through normal committed data.
healthy=[
 {'package':'./internal/pager','root':'TestSharedWALSnapshotsPromotionAndCheckpoint','source':'internal/pager/shared_session_test.go','line':57,'seams':['checkpointSharedCopy','checkpointSharedBackfill'],'reason':'Ordinary commits with pinned readers; checked busy results, completed checkpoint, SetBackfill and salt reset; page sizes 512/4096/65536. Shared helpers use OpenSharedSession and successful BumpSchemaCookie/Commit; no injected I/O or process control.'},
 {'package':'./sqlite','root':'TestNativeWALConnectionLifecycle','source':'sqlite/wal_test.go','line':14,'seams':['checkpointExclusiveCopy','checkpointExclusiveRetired'],'reason':'Explicit WALExclusive; successful commits, retained WAL reopen, checked public DB.Checkpoint and absent -wal, then a new generation. DB.Checkpoint routes to pager.Session.Checkpoint; no subprocess or manual tag.'},
 {'package':'./sqlite','root':'TestReviewEncryptionSharedLatestCheckpointMetadata','source':'sqlite/encryption_shared_review_test.go','line':228,'seams':['checkpointBeforeRootRename','checkpointAfterRootRename','checkpointAfterRootDirSync'],'reason':'EncryptionWALShared; normal create/commit and refreshed head checkpoint; checks latest geometry and VerifyEncrypted WALSegments==0. DB.Checkpoint -> EncryptedSession.Checkpoint -> Store.Checkpoint -> Publish -> publishRoot. Both checkpoint and rekey adapters are empty default stubs without manual tags.'}
]
for row in healthy:
 raw=(W/row['source']).read_bytes();assert ('func '+row['root']+'(t *testing.T) {').encode() in raw;assert not raw.startswith(b'//go:build');row['source_sha256']=sha(raw)
healthy_report={'status':'SOURCE_CLOSURE_AUDIT_ONLY / NOT_RUN','recommended_roots':healthy,'count':3,'all_seven_default_seams':True,'no_manual_tags':True,'not_selected':{'root':'TestSimilarityNativeTransactionsRebuildReopenCheckpoint','reason':'Its explicit Checkpoint is only in the WALShared branch; redundant shared coverage would omit the exclusive seams if substituted for TestNativeWALConnectionLifecycle.'},'default_sources':{p:sha((O/p).read_bytes()) for p in ['internal/pager/checkpoint_observation_default.go','internal/encstore/checkpoint_observation_default.go']}}
(E/'healthy-default-closure-audit.json').write_text(json.dumps(healthy_report,indent=2)+'\n')
roots=json.loads((R/'checkpoint-guard-overlay/AFFECTED-ROOTS.json').read_text());rootfiles={}
for p in sorted(files):
 if p.endswith('_test.go'):
  for n in re.findall(r'^func (Test\w+)\(t \*testing\.T\)',(O/p).read_text(),re.M):rootfiles[n]=p
assert all(n in rootfiles for n in roots['new_guard_roots']+roots['pure_model_roots']+roots['native_roots_never_executed_here'])
assert len(roots['new_guard_roots'])==8 and len(roots['pure_model_roots'])==12 and len(roots['native_roots_never_executed_here'])==3 and len(roots['existing_directly_affected_guard_roots'])==30
existing='\n'.join(((O/p.relative_to(W)) if (O/p.relative_to(W)).exists() else p).read_text() for p in (W/'internal/testscope').glob('*_test.go'))
for n in roots['existing_directly_affected_guard_roots']:assert 'func '+n+'(t *testing.T)' in existing,n
roots['status']='NOT_RUN; exact existing reviewed finite inventory plus three specifically requested healthy-default roots';roots['healthy_default_roots']=healthy
roots['selectors']={'./internal/testkit/checkpointrestart':'^('+'|'.join(roots['pure_model_roots'])+')$','./internal/testscope':'^('+'|'.join(roots['new_guard_roots']+roots['existing_directly_affected_guard_roots'])+')$','healthy_default_pager':'^TestSharedWALSnapshotsPromotionAndCheckpoint$','healthy_default_sqlite':'^(TestNativeWALConnectionLifecycle|TestReviewEncryptionSharedLatestCheckpointMetadata)$'}
(E/'FINITE-PLANNED-TESTS.json').write_text(json.dumps(roots,indent=2)+'\n')
finalfiles=[];patch=[];formatdiff=[]
for p,d in sorted(files.items()):
 before=(B/p).read_bytes();after=(O/p).read_bytes();wb=(W/p).read_bytes() if (W/p).exists() else b'';assert (sha(wb) if (W/p).exists() else None)==d['w_before_sha256'],p
 finalfiles.append({'path':p,'bytes':len(after),'sha256':sha(after),'reviewed_sha256':sha(before),'gofmt_sha256':sha((F/p).read_bytes()) if p.endswith('.go') else None,'changed_by_gofmt':p.endswith('.go') and (F/p).read_bytes()!=before,'changed_after_gofmt':p.endswith('.go') and after!=(F/p).read_bytes(),'baseline_sha256':d['w_before_sha256'],'change':d['change'],'source_group':d['source_group']})
 patch+=list(difflib.unified_diff(wb.decode().splitlines(True),after.decode().splitlines(True),'a/'+p if wb else '/dev/null','b/'+p))
 formatdiff+=list(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),'reviewed/'+p,'formatted-released/'+p))
(E/'FINAL-INTEGRATION.patch').write_text(''.join(patch));(E/'FINAL-FORMAT-SYNC.diff').write_text(''.join(formatdiff))
(E/'changed-paths.txt').write_text(''.join(d['path']+'\n' for d in finalfiles))
(E/'final-sync-proof.json').write_text(json.dumps({'pin_and_snapshot_changes_only_in_two_maps_per_guard':True,'all_other_guard_policy_bytes_equal_post_gofmt':True,'eleven_anchor_changes_revert_exactly_to_post_gofmt_test_source':True,'all_other_sources_equal_post_gofmt':True,'both_input_manifests_unchanged':True,'r5_anchors_verified':47,'checkpoint_anchors_verified':73,'no_tests_compiler_scanner_native_execution':True},indent=2)+'\n')
for name,want in [('checkpoint-extension','dd9e49ac002db6d2c57e0cadcc1e1fbdf94d8131ee4fc86c136db448d7523441'),('checkpoint-guard','edaa9bac8613930b4cf0440a0ab9d3d0443864c904c4421739c0ef88d276cf60')]:assert sha((R/(name+'-overlay')/'OVERLAY-MANIFEST.json').read_bytes())==want
manifest={'schema':'checkpoint-approved-format-overlay-v1','status':'SOURCE_FORMATTED_PIN_SNAPSHOT_RELEASED / COMPILER_TEST_NATIVE_NOT_RUN','overlay':str(O),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewed_facility_manifest_sha256':'dd9e49ac002db6d2c57e0cadcc1e1fbdf94d8131ee4fc86c136db448d7523441','reviewed_guard_manifest_sha256':'edaa9bac8613930b4cf0440a0ab9d3d0443864c904c4421739c0ef88d276cf60','reviews':m['reviews'],'scope':{'fixed_cases':10,'profiles':3,'fixture_rows':315,'new_production_seams':7,'pure_roots':12,'new_guard_roots':8,'native_roots_not_executed':3},'format':{'gofmt_sha256':'5583dbb3339147fee7cdb067eb3cd4a50015b48c27084377f49d93833aa4ad77','invocations':1,'go_files':23,'files_changed':14,'import_sort':'only contract.go encoding/hex before encoding/json','no_behavior_changes':True},'sync':{'r5_shared_pins_released_first':3,'checkpoint_pins':18,'r5_snapshots_verified':9,'checkpoint_snapshots_verified':17,'checkpoint_mutant_anchors':73,'format_only_anchor_adaptations':11,'rekey_mutant_anchors':47,'six_legacy_main_pin_updates':'NOT_APPLIED; exact current-W one-literal plan included','final_main_sha256':'9d29dda532e851dd0fa2211473a5abb24309f798a849483c7efca09a7a3a058f','prior_ordinary_function_pin_unchanged':'98341345e43f39b39dbc78eaf49a916a0701f3d7f2f383d4949b9a3ed439d199'},'W_overlay_and_six_pin_owner_sources_unchanged_by_worker':True,'files':finalfiles,'evidence':{}}
for p in sorted(E.glob('*')):
 if p.is_file() and p.name!='FINAL-MANIFEST.json':manifest['evidence'][p.name]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
(E/'FINAL-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'final_manifest':str(E/'FINAL-MANIFEST.json'),'sha256':sha((E/'FINAL-MANIFEST.json').read_bytes()),'files':len(finalfiles),'gofmt_changed_paths':[d['path'] for d in finalfiles if d['changed_by_gofmt']],'released_pin_owners':[d['path'] for d in finalfiles if d['changed_after_gofmt']],'finite_tests':len(roots['new_guard_roots'])+len(roots['existing_directly_affected_guard_roots'])+len(roots['pure_model_roots'])+len(healthy),'all_native_not_run':True},indent=2))
