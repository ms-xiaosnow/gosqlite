from pathlib import Path
import datetime, gzip, hashlib, io, json, re, subprocess, tarfile, zipfile

R=Path('/workspace/scratch/5e06a74e5f65/restart-20261012T2033')
W=R/'gosqlite'; OUT=R/'checkpoint-validation-evidence'; FULL=OUT/'bundle'; GIT=R/'checkpoint-validation-git-evidence'
BASE='b06606020fdbb5b73dd0e9b000773f3f02c6979d'; TREE='ffc73262e0314f46827b7f4cee1cdac766dbd889'
RUNS=['checkpoint-focused-validation','checkpoint-focused-validation-v2','checkpoint-default-race-validation','checkpoint-metadata-source-validation']
REVIEWS=['checkpoint-extension-independent-review.md','checkpoint-guard-independent-review.md','checkpoint-format-independent-review.md','checkpoint-unused-import-fix-independent-review.md']
assert not OUT.exists() and not GIT.exists()
FULL.mkdir(parents=True); GIT.mkdir()
def sha(b): return hashlib.sha256(b).hexdigest()
def put(p,b): p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
def jwrite(p,v): put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def get(p): return json.loads(p.read_text())
def cp(p,q): assert p.is_file() and not p.is_symlink(); put(q,p.read_bytes())
def git(*args): return subprocess.run(['git','-C',str(W),*args],capture_output=True,check=True).stdout
def blob(path): return git('cat-file','blob',TREE+':'+path)

identity=get(R/'checkpoint-unused-import-fix/SOURCE-IDENTITY.json')
assert identity['source_tree']==TREE and identity['base_commit']==BASE
paths=git('diff','--name-only',BASE,TREE).decode().splitlines(); assert len(paths)==30
source_rows=[]
for path in paths:
    data=blob(path); assert sha(data)==identity['files'][path]
    put(FULL/'final-source'/path,data)
    source_rows.append({'path':path,'bytes':len(data),'sha256':sha(data),'git_blob':git('rev-parse',TREE+':'+path).decode().strip()})
put(FULL/'FINAL-SOURCE.patch',git('diff','--binary','--full-index',BASE,TREE))
excluded=[]
dirs=RUNS+['checkpoint-format','checkpoint-integration','checkpoint-unused-import-fix','checkpoint-extension-overlay','checkpoint-guard-overlay']
for dirname in dirs:
    for p in sorted((R/dirname).rglob('*')):
        if not p.is_file(): continue
        if p.name=='processes-before-format.txt':
            excluded.append({'path':str(p.relative_to(R)),'reason':'Unrelated process inventory is outside the evidence scope.'}); continue
        cp(p,FULL/'records'/p.relative_to(R))
standalone=REVIEWS+['checkpoint-extension-scope-source-notes.md','checkpoint-extension-source-proposal.md','checkpoint-focused-validation-proposal.md','checkpoint-guard-freeze.py','checkpoint-guard-integrate.py','prepare_checkpoint_format.py','run_checkpoint_focused_validation.py','run_checkpoint_focused_validation_v2.py','run_checkpoint_default_race.py','run_checkpoint_metadata_source.py','preserve_checkpoint_validation.py']
for name in standalone: cp(R/name,FULL/'records'/name)

allowed=set('PATH GOMAXPROCS GOENV GO111MODULE GOWORK GOTOOLCHAIN GOPROXY GOSUMDB GOAUTH GOFLAGS GOEXPERIMENT GOFIPS140 GODEBUG GOCACHEPROG GOCOVERDIR GORACE GOTELEMETRY GOROOT GOPATH GOMODCACHE GOCACHE TMPDIR GOTMPDIR GOOS GOARCH GOAMD64 CGO_ENABLED LC_ALL LANG TZ CC CXX'.split())
gates=[]; commands={}; metadata={}; counts={}; resources={}
for run in RUNS:
    D=R/run; commands[run]=get(D/'commands.json'); metadata[run]={}; resources[run]={}
    for name in ['start.json','STOP.json','completion.json']:
        if (D/name).exists(): metadata[run][name]=get(D/name)
    for cmd in commands[run]:
        assert set(cmd['environment'])<=allowed
        name=cmd['name']; row={'run':run,'gate':name,'status':'NOT_RUN'}; p=D/(name+'.result.json')
        if p.exists():
            res=get(p); row.update({'status':'PASS' if res['exit_code']==0 else 'FAIL','result':{k:v for k,v in res.items() if k not in ['selection','tests']},'result_record':'records/'+run+'/'+p.name})
            assert not res['resource_breach_latched'] and res['observer_error'] is None
            metadata[run][p.name]=res
            for stream in ['stdout','stderr']: assert sha((D/(name+'.'+stream)).read_bytes())==res[stream+'_sha256']
            ev=[]
            for line in (D/(name+'.stdout')).read_text().splitlines():
                try: v=json.loads(line)
                except json.JSONDecodeError: continue
                if isinstance(v,dict) and v.get('Test') and v.get('Action') in ['pass','fail','skip']: ev.append(v)
            count={a:sum(v['Action']==a for v in ev) for a in ['pass','fail','skip']}
            roots={a:sorted([{'package':v['Package'],'root':v['Test']} for v in ev if v['Action']==a and '/' not in v['Test']],key=lambda x:(x['package'],x['root'])) for a in ['pass','fail','skip']}
            row['test_events']={'named':count,'roots':roots,'root_counts':{k:len(v) for k,v in roots.items()}}
            counts[(run,name)]=row['test_events']
            before=get(D/(name+'.resources-before.json')); samples=[json.loads(s) for s in (D/(name+'.resources.jsonl')).read_text().splitlines()]
            assert before['qualified'] and all(s['qualified'] for s in samples)
            resources[run][name]={'before':before,'samples':samples}
        gates.append(row)

old=[g for g in gates if g['run']==RUNS[0]]
assert len(old)==11 and [x['status'] for x in old]==['PASS']*4+['FAIL']+['NOT_RUN']*6
failure=counts[(RUNS[0],'05_pure_models')]; assert failure['named']=={'pass':0,'fail':0,'skip':0}
assert '"bytes" imported and not used' in ''.join(json.loads(s).get('Output','') for s in (R/RUNS[0]/'05_pure_models.stdout').read_text().splitlines())
new=[g for g in gates if g['run']==RUNS[1]]; assert len(new)==8 and all(g['status']=='PASS' for g in new)
for run,gate,nroots,nnamed in [(RUNS[1],'05_pure_models',12,12),(RUNS[1],'06_ast_guards',38,120),(RUNS[1],'07_healthy_pager',1,4),(RUNS[1],'08_healthy_sqlite',2,5),(RUNS[2],'07_healthy_race',3,9),(RUNS[3],'12_metadata_source',1,1)]:
    c=counts[(run,gate)]; assert c['root_counts']=={'pass':nroots,'fail':0,'skip':0} and c['named']=={'pass':nnamed,'fail':0,'skip':0}
normal=counts[(RUNS[1],'07_healthy_pager')]['roots']['pass']+counts[(RUNS[1],'08_healthy_sqlite')]['roots']['pass']
assert sorted(normal,key=lambda x:(x['package'],x['root']))==counts[(RUNS[2],'07_healthy_race')]['roots']['pass']
for run in RUNS[1:]:
    c=metadata[run]['completion.json']; assert c['status']=='PASS' and c['source_unchanged'] and not c['manual_image_executed']

before=get(R/RUNS[0]/'source-before.json'); after=get(R/RUNS[1]/'source-before.json'); race=get(R/RUNS[2]/'source-before.json')
changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
assert changed==['internal/testkit/checkpointrestart/contract.go','internal/testscope/checkpoint_restart.go'] and after==race and after==get(R/RUNS[3]/'source-before.json')
for p in paths: assert after[p]['sha256']==identity['files'][p]
image_path=R/RUNS[1]/'checkpoint-sqlite.test'; image_data=image_path.read_bytes(); nm=get(R/RUNS[1]/'11_nm_manual_sqlite.result.json')['symbols']
assert sha(image_data)==nm['image_sha256'] and nm['required']==454 and nm['exact_root_set'] and not nm['image_executed']
image_record={'path':'records/'+RUNS[1]+'/'+image_path.name,'bytes':len(image_data),'sha256':sha(image_data),'required_symbols':454,'manual_root_symbols':nm['manual_symbols'],'image_executed':False}
reviews=[]
for name in REVIEWS:
    data=(R/name).read_bytes(); assert b'CLEAR' in data
    reviews.append({'path':'records/'+name,'sha256':sha(data),'verdict':'CLEAR','scope':'source review only; execution boundaries remain as stated in the original review'})

source_identity={'schema':1,'base_commit':BASE,'source_tree':TREE,'source_file_count':30,'files':source_rows,'full_source_identity_record':'records/checkpoint-unused-import-fix/SOURCE-IDENTITY.json','full_source_identity_sha256':sha((R/'checkpoint-unused-import-fix/SOURCE-IDENTITY.json').read_bytes()),'format_manifest_sha256':identity['format_manifest_sha256'],'correction_paths':changed,'freeze_policy':'All final source bytes are read from immutable Git tree objects, not mutable W.'}
reuse={'schema':1,'final_source_tree':TREE,'historical_source_tree':get(R/'checkpoint-integration/SOURCE-IDENTITY.json')['source_tree'],'reused_gates':[{'run':RUNS[0],'gate':name,'claim':'source file/tag/root selection only','status':'REUSED_PASS'} for name in ['02_list_linux_default','03_list_linux_manual','04_list_nonlinux_fallback']],
'basis':'Only the unused bytes import and its exact guard pin/template/import inventory changed. No filenames, build tags or roots changed. Earlier go-list selection remains applicable; its historical import data is not claimed as freshly regenerated final-tree metadata.',
'format_basis':'Original format/list gates passed. V2 freshly checks formatting only on the two correction files; unchanged formatted files retain original evidence.',
'source_manifest_comparison':{'old_entries':len(before),'new_entries':len(after),'changed_paths':changed,'V2_and_supplemental_race_manifests_identical':True,'old_sha256':sha((R/RUNS[0]/'source-before.json').read_bytes()),'new_sha256':sha((R/RUNS[1]/'source-before.json').read_bytes())},
'historical_failure':{'run':RUNS[0],'gate':'05_pure_models','exit_code':1,'cause':'unused bytes import','test_execution':'NONE: build failed before any Test event','remaining_commands':'NOT_RUN','corrected_by':'checkpoint-unused-import-fix','review':'checkpoint-unused-import-fix-independent-review.md'},
'not_run':['manual checkpoint interruption/process-exit/recovery native scenario','manual test-image execution','physical persistence qualification','oracle campaign','full repository suite','model or AST race rerun','unrelated tests'],
'separate_source_only_artifact':{'library_file_id':'libfile_06b177484f4881919a5c6e8171dd9baa','sha256':'5b18d3de184699e192179e2b84d7d464e281aeb06fcc585afe582ca603c52f18','status':'Prior separately preserved pending SOURCE_ONLY archive; this task does not reupload it.'}}
summary={'schema':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':BASE,'source_tree':TREE,'status':'PASS for the bounded evidence below; historical build FAIL preserved','focused_completed_utc':metadata[RUNS[1]]['completion.json']['utc'],'race_completed_utc':metadata[RUNS[2]]['completion.json']['utc'],'metadata_source_completed_utc':metadata[RUNS[3]]['completion.json']['utc'],'new_evidence':{'pure_models':{'roots':12,'named_pass':12},'AST_source_contracts':{'roots':39,'named_pass':121,'focused_roots':38,'focused_named_pass':120,'supplemental_metadata_source_roots':1,'supplemental_metadata_source_named_pass':1},'healthy_default_normal':{'roots':3,'named_pass':9},'healthy_default_race':{'roots':3,'named_pass':9},'V2_executed_gates':8,'race_executed_gates':1,'supplemental_metadata_source_gates':1,'sourceguard':'PASS','manual_compile_and_nm':'PASS; image NOT_EXECUTED'},'reused_go_list_gates':3,'historical_build_failures':1,'historical_named_test_failures':0,'manual_checkpoint_interruption_exit_recovery':'NOT_RUN','physical_persistence':'NOT_RUN','oracle_campaign':'NOT_RUN','full_suite':'NOT_RUN','image':image_record,'reviews':reviews,'gates':gates}
readme='''# R3/R4 checkpoint / 扩展索引：定向验证证据

## 结论与边界

最终受测源码树为 `ffc73262e0314f46827b7f4cee1cdac766dbd889`，基线提交为 `b06606020fdbb5b73dd0e9b000773f3f02c6979d`；相对基线共 30 个源码/说明路径。本档案的最终源码全部从不可变 Git 对象提取，不读取随后可能更新的工作树说明文件。

- 新执行：12 个纯模型根 / 12 个具名 PASS；38 个 AST 源码契约根 / 120 个具名 PASS；3 个现有健康默认数据库根 / 9 个具名 PASS。源码守卫、修复两文件格式检查、manual 编译及 nm 检查均 PASS。V2 于 2026-10-12 23:28:13 UTC 完成。
- 新补充：同 3 个健康默认数据库根的 race 检查 / 9 个具名 PASS，于 23:29:24 UTC 完成；零 FAIL、零 SKIP，源码清单未变。纯模型、AST、健康数据库证据分开统计。
- 另补充 1 个实际受影响的现有 VFS 静态消费者 `TestMetadataOwnershipCallChainSource`，1 根 / 1 个具名 PASS，于 23:30:52 UTC 完成；它扫描新 pager 源码，未触发数据库或 manual native。合计源码契约 39 根 / 121 个具名 PASS。
- 复用：首次执行的 Linux 默认、Linux manual 标签、非 Linux 回退共 3 项 go-list 文件/标签/根选择结果。两文件修复不改变文件名、标签或根集合。旧记录中的完整 import 内容不是最终树的新鲜元数据。未重跑完整仓库测试或无关测试。
- 已修正但保留的原始失败：首次 4 个格式/选择门通过，随后纯模型包因未使用 bytes import 编译失败，exit 1；没有任何 Test 事件，不能写成 12 根测试失败。后续 6 个原定门当次 NOT_RUN。删除该 import，并同步其精确 pin、完整模板及 import 清单后，独立窄审阅 CLEAR，V2 才获得上述新结果。
- 四份独立源码审阅均 CLEAR；审阅的历史 NOT_RUN 声明按原文保存。源码审阅 CLEAR 不等于物理结果。

## 仍未执行

manual checkpoint 中断、进程退出、恢复场景及其物理持久性验证均为 NOT_RUN；oracle campaign、完整套件也为 NOT_RUN。唯一 manual 测试映像只做 test -c 与 nm：454 个要求符号、精确根集合及 3 个 manual 根符号通过；映像从未执行。健康默认测试的真实数据库操作不是 manual 中断/恢复资格证据。不得将本档案表述为物理 PASS。

## 如何核验与使用

`RESULTS-SUMMARY.json` 为结果索引；`COMMANDS.json` 聚合原始命令及固定环境；`RUN-METADATA.json` 聚合每门结果、开始/停止/完成记录；`RESOURCES.json` 聚合资源采样；`REUSE-MAP.json` 解释复用、失败修复和未运行范围；`REVIEWS.md` 保留四份完整审阅。

Git-ready 文件中的 `RAW-RECORDS.tar.gz` 以固定 tar 时间、uid/gid 和 gzip mtime=0 保存原始 stdout/stderr、资源日志、原始 JSON 记录、格式/修复差异及 runner。解包后的每个字节可按 `FULL-ARCHIVE-INDEX.json` 中 SHA-256 核验。Git 不放编译映像、重复源码树或历史 before 源码树。完整 ZIP 另含最终 30 文件快照、修复/格式前后材料、四个执行阶段的全部原始证据及唯一未执行映像。

`MANIFEST.json` 列出完整 ZIP 除自身外所有成员及 SHA-256；`LOCAL-ARCHIVE-VERIFICATION.json` 记录 ZIP 整体摘要；`LIBRARY-ARCHIVE.json` 在外置回执中记录一次上传的精确身份、回读及全部成员核验结果。先前独立保存的 SOURCE_ONLY 档案只在 REUSE-MAP 中引用，不重复上传。

归档过程只使用文件读写、Python 哈希/JSON/压缩、只读 Git 对象读取和 Library 保存/回读。没有运行新 Go、格式化、解析器、编译器、测试、映像或物理场景，没有修改工作树或 GitHub。保留固定非秘密工具/环境记录，排除无关进程清单、凭据、签名链接和其他项目资料。
'''
put(FULL/'README-zh.md',readme.encode())
put(FULL/'REVIEWS.md',('\n\n'.join('<!-- Original: '+name+' -->\n'+(R/name).read_text() for name in REVIEWS)).encode())
for name,value in [('SOURCE-IDENTITY.json',source_identity),('RESULTS-SUMMARY.json',summary),('REUSE-MAP.json',reuse),('COMMANDS.json',commands),('RUN-METADATA.json',metadata),('RESOURCES.json',resources),('EXCLUSIONS.json',excluded)]: jwrite(FULL/name,value)

# Scan only task-selected text, and never include process dumps or transfer URLs.
patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'sk-(?:proj-)?[A-Za-z0-9_-]{30,}',rb'(?i)(?:X-Amz-Signature|[?&]sig)=[A-Za-z0-9%+/]{16,}',rb'(?i)Authorization:\s*Bearer\s+[A-Za-z0-9._~-]{20,}']
for p in FULL.rglob('*'):
    if p.is_file() and p.suffix!='.test': assert not any(re.search(x,p.read_bytes()) for x in patterns),('potential secret',str(p.relative_to(FULL)))
rows=[{'path':str(p.relative_to(FULL)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(FULL.rglob('*')) if p.is_file()]
jwrite(FULL/'MANIFEST.json',{'schema':1,'hash_algorithm':'sha256','manifest_excludes_itself':True,'member_count_without_manifest':len(rows),'files':rows})
zip_path=OUT/'gosqlite-R3-R4-checkpoint-focused-validation-ffc7326.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(FULL.rglob('*')):
        if p.is_file():
            zi=zipfile.ZipInfo(str(p.relative_to(FULL)),(2026,10,12,23,30,52)); zi.compress_type=zipfile.ZIP_DEFLATED; zi.external_attr=0o100644<<16
            z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
assert zip_path.stat().st_size<50*1024*1024
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and len(z.namelist())==len(rows)+1
    for row in rows: assert sha(z.read(row['path']))==row['sha256']
    assert sum(n.endswith('.test') for n in z.namelist())==1
local={'status':'PASS','zip_name':zip_path.name,'bytes':zip_path.stat().st_size,'sha256':sha(zip_path.read_bytes()),'members':len(rows)+1,'verified_nonmanifest_members':len(rows),'manifest_sha256':sha((FULL/'MANIFEST.json').read_bytes()),'unexecuted_image_members':1,'immutable_source_files_verified':30}
jwrite(OUT/'LOCAL-ARCHIVE-VERIFICATION.json',local)

# Aggregate raw evidence into one reversible deterministic tar+gzip; no source trees/images in Git.
raw=[]
for row in rows:
    rel=Path(row['path'])
    if rel.parts[0]!='records': continue
    rp=Path(*rel.parts[1:]); p=FULL/rel
    if p.suffix=='.test' or p.name in ['source-before.json','source-identity.json','SOURCE-IDENTITY.json']: continue
    if rp.parts[0] in ['checkpoint-extension-overlay','checkpoint-guard-overlay']: continue
    if any(part in ['before','after-gofmt','overlay','evidence'] for part in rp.parts): continue
    if p.name in REVIEWS: continue
    raw.append(row)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
    for row in raw:
        data=(FULL/row['path']).read_bytes(); info=tarfile.TarInfo(row['path']); info.size=len(data); info.mtime=0; info.mode=0o644; info.uid=info.gid=0; info.uname=info.gname=''
        tar.addfile(info,io.BytesIO(data))
raw_bytes=gzip.compress(buf.getvalue(),compresslevel=9,mtime=0); put(GIT/'RAW-RECORDS.tar.gz',raw_bytes)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(raw_bytes)),mode='r:') as tar:
    assert len(tar.getnames())==len(raw)
    for row in raw: assert sha(tar.extractfile(row['path']).read())==row['sha256']
for name in ['README-zh.md','SOURCE-IDENTITY.json','RESULTS-SUMMARY.json','REUSE-MAP.json','COMMANDS.json','RUN-METADATA.json','RESOURCES.json','REVIEWS.md','EXCLUSIONS.json','MANIFEST.json']: cp(FULL/name,GIT/name)
cp(OUT/'LOCAL-ARCHIVE-VERIFICATION.json',GIT/'LOCAL-ARCHIVE-VERIFICATION.json')
raw_set={x['path'] for x in raw}
jwrite(GIT/'FULL-ARCHIVE-INDEX.json',{'schema':1,'archive':local,'library_record':'LIBRARY-ARCHIVE.json','raw_records':{'path':'RAW-RECORDS.tar.gz','bytes':len(raw_bytes),'sha256':sha(raw_bytes),'members':len(raw),'gzip_mtime':0,'tar_metadata':'uid=gid=mtime=0; mode=0644; empty uname/gname'},'files':[r|{'git_storage':'RAW-RECORDS.tar.gz:'+r['path'] if r['path'] in raw_set else (r['path'] if (GIT/r['path']).exists() else 'full Library archive only')} for r in rows]})
print(json.dumps(local)); print('git_ready_files',sum(p.is_file() for p in GIT.rglob('*')),'git_ready_bytes',sum(p.stat().st_size for p in GIT.rglob('*') if p.is_file()))
