# R3/R4: one finite checkpoint-interruption facility and extension ledger

Status: SOURCE-ONLY PROPOSAL / NOT IMPLEMENTED / NOT_RUN. Prepared 2026-10-12 against `gosqlite` main `01c63e6f8fb3d9e196afe2f42a163eb3eac4ad5a`, the fixed R1–R6 checklist, and the R5 source-only overlay. This document does not authorize execution. No Go program, parser executable, compiler, test, database fixture, checkpoint, process controller, fault, or ANN reporting/campaign was run to prepare it. Only source was read and this document written.

## Decision

Implement **one controller, ten closed case IDs, three authority profiles, one combined 315-row fixture, one complete extension ledger, and one independent reopen child per case**. A case determines its profile; there is no case × profile × index product. All ten use all three indexes. There is no separate R4 process facility, old A5 change, R5 case/credential change, ANN V4 invocation, or new production index algorithm.

Ten cases consist of three ordinary completion controls and seven interruption cuts. Controls are necessary to establish the exact observer sequence and complete public lifecycle in each genuinely different authority path. No separate returned-no-ACK or acknowledged-exit checkpoint cases are needed: the already committed transaction has an external durable receipt before checkpoint starts; checkpoint is not a new SQL commit.

The source-only end point is reviewed model/caller/hooks/guard/manual source plus separately authorized finite validation. Native interruption/reopen and physical persistence qualification remain NOT_RUN. Neither model consistency nor a compiled caller is a physical PASS.

## 1. Source-grounded authority and API facts

- `sqlite/sqlite.go:542`, `DB.Checkpoint`: checks context, holds the DB mutex, rejects closed/read-only/no-session/active Tx/live Rows, delegates to its session, and refreshes `d.info` only on nil. The caller must use this public method with no local lease. Do not bypass it with direct pager/Store checkpoint calls. Its broad comment about ending a WAL generation must not be used to override the actual shared implementation.
- `internal/pager/checkpoint.go`: exclusive checkpoint first protects sectors, syncs WAL, copies the sorted selected page set, truncates main, syncs main, closes WAL once, unlinks WAL, unlinks stale SHM, syncs directory, and refreshes main. Errors after physical work poison the session. The durable committed WAL remains authoritative through a partial main copy.
- `internal/pager/shared_checkpoint.go`: freezes the WAL under checkpoint/write locks and read marks; rechecks generation after READ_LOCK(0); sets attempted, syncs WAL, copies selected pages, possibly truncates main, syncs main, then sets backfill. It retains main/WAL/SHM inodes. `SetBackfill` is transient SHM publication, not an fsync or a durable SQL acknowledgement.
- `internal/pager/shared_index.go`: a fresh writable shared open can reconstruct transient SHM from a supported committed WAL under the existing locks. Read-only shared open requires a live initialized SHM; it is not a universal cold-recovery probe. Reconstruction is not permission for tail repair or fallback.
- `internal/encstore/publish.go:Checkpoint`: shared maintenance when relevant, Check/context/CopyBudget/Verify, then `Publish(..., target=nil)`. It does nothing if there is no WAL/segment. Therefore layout 1 is an invalid encrypted-checkpoint test profile. Choose **EncryptionWAL / storage layout 2**; layout 3 uses the same immutable publication authority and adds maintenance already covered by ordinary paths. This proposal does not claim interrupted layout-3 maintenance coverage and does not add it as a requirement.
- Encrypted layout 2 requires a different identity predicate from R5: `nextDescriptor` uses `s.HeadCommitID()` as parent; WAL HeadCommitID is an authenticated object-reference commit ID, **not SHA256(root bytes)** (`snapshot.go:146`, `wal_format.go:106–120`, `store.go:388`). The checkpoint candidate keeps the same complete Epoch, DBID, credential kind, RootSalt, and key. It creates fresh base/root FileIDs and one next storage sequence. There is no OLD-key/NEW-key pair.

Profiles are Linux/plain-exclusive/4096, Linux/plain-shared/4096, and Linux/encrypted-layout2/raw-key256/4096. Plain profiles set logical PageSize=SectorSize=4096 and do not assert actual device-sector size or enable WALPowersafeOverwrite. One source-built fixture only; no imported WAL, concurrent reader/writer, tail, or partial-readmark cases. Every source-selected copy set must have at least two pages, so “after first copy” is truly before completion.

## 2. Closed case/authority table

OLD and NEW below mean **checkpoint representation**, never an older SQL transaction. Let C be the final acknowledged committed SQL/index head and B the earlier 312-row, no-extension baseline. **Every accepted reopen must recover exactly C. B, any missing extension, and any mixed ledger are failures.**

| Fixed case ID | Exact interruption position | Required same-kernel post-Wait observation / authority |
|---|---|---|
| exclusive-control | No interruption; traverse both exclusive points, public nil, clean Close | Main represents C; WAL absent; clean public owners |
| exclusive-after-first-main-copy | Immediately after the first successful selected-page `writeFullAt`, before the second copy/Truncate/main Sync | OLD authority: original complete committed WAL still present and byte-identical; main may be partly copied; public reopen yields C |
| exclusive-after-wal-unlink | Immediately after successful `os.Remove(path+"-wal")`, before SHM removal/final directory Sync | NEW visible authority: main already synced, WAL absent, C in main; public checkpoint did not return and no checkpoint ACK exists |
| shared-control | No interruption; traverse both shared points, public nil, clean Close with KeepWALOnClose | Stable original WAL retained; full backfill completed in this session; C |
| shared-after-first-main-copy | Immediately after first successful selected-page copy, before remaining copies/main Sync/SetBackfill | OLD shared publication state; original WAL retained; attempted=safe, pre-cut backfill remains old value; C |
| shared-after-backfill | Immediately after successful `SetBackfill(safe)`, before the trailing busy/return branch | NEW backfill publication with main already synced, same WAL authority retained, safe=MaxFrame; C |
| encrypted-control | Traverse all three root cuts; public nil; clean Close with KeepWALOnClose | NEW authenticated selected root/base, same Epoch, no active segments, C |
| encrypted-before-root-rename | After candidate/root verification, candidate and retained-root namespace preparation and sync, final authority checks/context check; before `attempted=true` | OLD selected root byte hash and authenticated old head unchanged; prepared candidate is not selected; C |
| encrypted-after-root-rename | After successful rename, before final namespace Sync | NEW selected root visible in this kernel; no claim of directory durability/public return; C |
| encrypted-after-root-dirsync | After successful final namespace Sync, before final root-open/revalidation/adoption | NEW selected root and completed namespace Sync; public return/handle adoption not claimed; C |

For the fixed **controlled process-exit** caller, a successful rename followed by self-exit must observe NEW; accepting OLD here would hide a mispositioned cut. A future actual power-loss experiment could need OLD-or-NEW across an unsynced namespace boundary, but this proposal neither performs nor codes that experiment. Conversely, requiring a new key after checkpoint would be wrong. Shared reopen may reset/reconstruct SHM/backfill; it must not be required to preserve a copied transient backfill scalar. The cut receipt records what the original owning session published.

No arbitrary “open succeeded”, ErrBusy, ErrUnsupported, ErrCorrupt, authentication error, lower-level Sync error, or missing cut counts as an acceptable alternative to C.

## 3. Minimal production seams and files

### Existing production files: only inserted void observation calls

1. `internal/pager/checkpoint.go`:
   - One void copy observation directly after the successful `writeFullAt` branch in the sorted page loop. Supply context, constant exclusive authority/point, path, current page number, selected-page count, DBSize, frame count, and already available WAL generation/checksum scalars. No descriptor, Session, map, page buffer, or callback crosses the seam.
   - One void retirement observation directly after successful WAL unlink, before SHM removal. Supply context and constant exclusive-retired point plus existing public/scalar head fields. Do not move close, nil assignment, unlink, Sync, refresh, or error handling.
2. `internal/pager/shared_checkpoint.go`:
   - Same scalar copy observer directly after successful `writeFullAt`, with current page, len(images), h.DBSize, h.MaxFrame, salts/checksum, safe and old backfill.
   - One void observation directly after successful `SetBackfill(safe)`, carrying the same captured generation and safe/backfill values. Do not add a second index read, lock, Sync, SetBackfill, or unlock.
3. `internal/encstore/publish.go`:
   - Three new **checkpoint-named** void calls at the exact before-rename / after-successful-rename / after-successful-final-directory-Sync locations used by the R5 overlay. They receive context, constant point, path, old-root ciphertext and candidate-root ciphertext; the manual adapter hashes/copies bounded public headers, retaining no slices.
   - Do not rename, broaden, route through, or edit R5's `rekeyPublicationObserve`, six-case model, layout-1 extent, key-purpose, or provider rules. If R5 is integrated first, place each new call adjacent to its existing inert-for-this-context R5 call and independently re-review the shared production source pins.

Removing only the new observation lines must reproduce the chosen integrated production baseline byte-for-byte. Default source semantics and operation/error order stay unchanged; machine-code identity is not asserted.

### Proposed new source inventory

- `internal/pager/checkpoint_observation.go`: tiny private point/scalar vocabulary; no native capabilities.
- `internal/pager/checkpoint_observation_default.go`: exact `!linux || !manual_checkpoint_restart` tag; empty void stubs importing only what signatures need.
- `internal/pager/checkpoint_restart_manual_linux.go`: exact complementary `linux && manual_checkpoint_restart` tag; scalar adapter to the common manual bridge.
- `internal/encstore/checkpoint_observation.go`, `checkpoint_observation_default.go`, `checkpoint_restart_manual_linux.go`: parallel private vocabulary/default stub/thin manual root adapter. The root adapter supports layout-2 bounded root lengths, not R5's fixed 680-byte layout-1 root. It decodes only already-authenticated public headers, copies them into value receipts, and invokes the common bridge. It never invokes a storage or crypto writer.
- `internal/testkit/checkpointrestart/contract.go`, `contract_test.go`: descriptor-free closed ten-case authority/trace/receipt model.
- `internal/testkit/checkpointrestart/extension_ledger.go`, `extension_ledger_test.go`: bounded fixture constants, typed row/ledger values, literal expected rows/counts/query expectations, independent ASCII gram and IVF membership predicates. No sqlite/pager/encstore imports, filesystem, process, callbacks, or native constructors.
- `internal/testkit/checkpointrestart/manual_linux.go`: Linux/manual-only common fixed-pipe channel, one-purpose context scope, scalar observation tracking, bounded frame codec, and exact child self-exit. The ordinary package has no such capabilities. Thin pager and encstore adapters share this one implementation, not parallel channel frameworks.
- `sqlite/checkpoint_restart_manual_linux_test.go`: one controller and fixed writer/probe role roots, shared seed/ledger/family/owner helpers, all behind the exact new tag.
- `internal/testscope/checkpoint_restart.go`, `checkpoint_restart_test.go`: closed source and semantic-AST guard/mutants, including the common bridge file.
- Necessary exact integration in `internal/testscope/main.go` and `oracle_startup.go`; preserve all old scanners/predicates and A8/R5 whole-main obligations.
- `docs/testing/checkpoint-restart-manual-zh.md`: finite preparation, authority table, owner/probe rules, limits, failure/unknown statuses, and NOT_RUN. No native launch recipe or implied authorization.

The common manual context is an immutable **checkpoint** purpose bound to trial, source, binary, fixture, case/profile, role, path, old committed head and channel challenge. Only the admitted writer installs it immediately around the single `db.Checkpoint(ctx)` call. No global arm/disarm function, action callback, arbitrary file descriptor, function-valued operation, caller-selected offset, or rekey credential is accepted. Guards must reject reuse for Exec/Commit/Rekey/Publish/Close or another path.

Copy calls occur on each selected page, but the bridge emits a pipe barrier only for the first and maintains bounded strictly increasing page/count scalars for subsequent calls. At the terminal exclusive/shared observation it requires the number observed to equal the supplied selected-page count. A first-page interruption sees exactly one copy. A control/terminal cut cannot silently omit later copies. Maximum observed copies is 4096; no per-page pipe/event expansion.

No DB/Session/Store re-entry or extra native read happens under an observer. It may hold only its own short context-state mutex while validating scalar progression, release it before the pipe exchange, then self-exit on the parent’s exact grant. Existing engine locks remain held as the production operation requires; the observer must not try to reacquire them.

## 4. Single fixture: actual ordinary SQL and sizes

Choose three small known ordinary fixtures rather than inventing an unverified tiny ANN graph or multiplying controllers. Final total is **7 grams rows + 180 HNSW rows + 128 IVF rows = 315 user rows**. Each table has just one index method, avoiding planner selection ambiguity. These sizes and search obligations come from:

- `sqlite/similarity_native_test.go:TestSimilarityNativeCandidateSeeksAndBusinessFilter` (7 rows, real grams posting search).
- `sqlite/ann_query_test.go:annQueryFixture`, `TestANNQueryNativeExactDefaultAndRealSearch` (180 rows, real HNSW graph search).
- `sqlite/ivf_query_test.go:ivfQueryFixture`, `TestIVFQueryRealSelectedListAndExactDefault` (4 clusters × 32 rows, true one-list IVF search).
- `sqlite/ann_storage_test.go`, `ivf_storage_test.go`, `extension_storage_test.go`: public creation/check/lifecycle APIs and exact shadow SQL.
- `sqlite/ivf_review_test.go:reviewIVFMemberships`: independent scalar nearest-centroid oracle.

These existing ordinary fixtures are source evidence, not a claimed validation of this newly composed fixture.

### Schema and exact final rows

Three literal CREATE statements:

    CREATE TABLE docs(id INTEGER PRIMARY KEY,body,active INTEGER)
    CREATE TABLE hitems(id INTEGER PRIMARY KEY,embedding VECTOR(3) NOT NULL,active INTEGER,title TEXT)
    CREATE TABLE iitems(id INTEGER PRIMARY KEY,embedding VECTOR(3) NOT NULL,active INTEGER,title TEXT)

`docs` final rows, including all types and NULL:

    (-9, 'abcd', 0), (1, 'abce', 1), (2, 'abcf', 1),
    (3, NULL, 1), (4, 'disjoint', 1), (5, '', 1), (6, 'a', 1)

`hitems`: integer i=1..180, vector SQL parameter `fmt.Sprintf("[%d,%d,1]", i, i%7)`, active integer 1 iff i%19==0 else 0, title `fmt.Sprintf("item %d", i)`.

`iitems`: cluster c=0..3 and offset o=0..31, id=c*32+o+1; vector parameter exactly `fmt.Sprintf("[%f,%f,1]", float64(c*1000)+float64(o)/100, float64(c*500)+float64(o)/200)`; active integer 1 iff c==3 else 0; title `fmt.Sprintf("item %d", id)`. This preserves the ordinary fixture's six-decimal formatting and float32 conversion, rather than comparing mathematically ideal decimal values to persisted float32s.

### Exactly two data transactions and one preparatory checkpoint

1. Open a new private family with the case profile, PageSize 4096, KeepWALOnClose true, MaxTransactionPages 4096, MaxTransactionUndoBytes 64 MiB, MaxSortBytes 64 MiB. Plain SectorSize is 4096. Create all three tables and insert the final rows **except** docs id=2, hitems id=180, and iitems id=128 in one Tx, then public Commit.
2. Public DB.Checkpoint with an ordinary context and no armed observation. This creates B: 312 rows and no extension indexes. Complete and close all read leases.
3. One final Tx inserts those three omitted rows using the same literal/formula data and calls, in this fixed order:
   - `tx.CreateGramsIndex(ctx, "docs_grams", "docs", []string{"body"})`
   - `tx.CreateHNSWIndex(ctx, "hitems_hnsw", "hitems", "embedding")`
   - `tx.CreateIVFFlatIndex(ctx, "iitems_ivf", "iitems", "embedding", sqlite.IVFFlatIndexOptions{Lists:4})`
   All other index options use their current fixed ordinary defaults. Capture the complete normalized persisted configuration in the ledger. Commit once, capture its actual nil result adjacently, then validate C fully below. No REINDEX/repair is allowed in verification.
4. The controller creates an exclusive external committed-head receipt in its separate control directory, with actual Commit-nil origin, C's complete ledger digest, selected head identity, source/binary/profile/fixture binding; full write, file Sync, one Close, directory Sync/Close, identity/hash readback. It is not a checkpoint-return ACK. Refuse any durability/owner failure.
5. Close seed DB with KeepWALOnClose true once; validate no pending native owners, then freeze the complete original family. Copy to a new writer family, preserving all entries but with distinct inodes. The writer must independently recheck C and the exact expected WAL/root head before the parent grants Checkpoint.

For encrypted layout 2 the expected sequence is initial empty publication 1, baseline data transaction 2, preparatory checkpoint 3, indexed data transaction 4; one selected segment remains at C. Require actual authenticated sequence=4 and WALSegments=1 rather than silently adjusting an unexpected sequence. The interrupted checkpoint creates storage sequence 5, not a different SQL head or epoch. If exact source construction later reveals a different sequence, revise the source freeze before running; do not weaken the predicate at runtime.

### Fixed limits

- One case per admission, three fixed roles (controller, writer, probe), at most two child Starts and two owned Waits. No child spawning or concurrent live children.
- 64 frames per child, 4096 bytes per canonical frame, monotonic sequence, 64 KiB per stdout/stderr diagnostic stream. Final ledger is a separately hashed bounded artifact, not stuffed into pipe frames.
- 4096 logical pages, 4096 copied pages, 4096 plaintext WAL frames, 32 MiB maximum single family file, 64 MiB total family bytes, 64 family entries. Main bytes are separately bounded by 4096*4096. SQL receipt at most 4 MiB, 4096 combined result rows, 64 KiB per cell, 64 schema entries. The fixed source arrays and index counts are far smaller; overflow refuses admission instead of scaling the workload.
- Bounded `wal.Scan` on owned immutable bytes: MaxWALBytes=32 MiB, MaxFrames=4096, MaxIndexEntries=8192, MaxDBPages=4096, MaxIndexWork=1<<20. Require Complete, clean tail, one known final committed head; never repair a suffix.
- `DB.Check(CheckOptions{MaxPages:4096, MaxPageReads:1<<20})`. Existing persisted extension and search defaults remain finite; do not describe these as total heap/RSS/OS-I/O bounds.
- Encrypted retention: at most 16 successful generations, 64 directory entries, 64 MiB retained bytes. Keep the ordinary documented finite encryption WAL limits; impose the smaller fixture/file/receipt admission bounds separately. No numeric claim that 64 MiB is sufficient until the later authorized composed-fixture check actually establishes it.
- A 30-second diagnostic wait may report a stall, but it is not a kill deadline and cannot retire a process or permit dependent probes. Actual unresolved Wait remains owned indefinitely as in the corrected R5 pattern.

## 5. Complete committed SQL/index ledger

Use the following **13 complete ordered streams**, never COUNT-only, a sample, LIMIT, or an unordered hash. Every Rows owner records exact SQL/args, typed values, complete EOF, nil Rows.Err, and one public Rows.Close after successful exhaustion. Copy BLOB values before advancing. Failure at EOF/lease retirement is retained and never retried via Close to manufacture success.

1. `SELECT id,body,active FROM docs ORDER BY id`
2. `SELECT id,embedding,active,title FROM hitems ORDER BY id`
3. `SELECT id,embedding,active,title FROM iitems ORDER BY id`
4. `SELECT type,name,tbl_name,rootpage,sql FROM sqlite_schema ORDER BY name`
5. `SELECT id,name,source_table,source_hash,method,method_version,storage_version,config,config_hash,generation,needs_reindex,source_rows,schema_cookie FROM __gosqlite_ext_catalog ORDER BY id`
6. `SELECT id,index_id,field_id,column_name,column_ordinal FROM __gosqlite_ext_fields ORDER BY id`
7. `SELECT id,index_id,field_id,namespace,gram_length,gram,content_rowid FROM __gosqlite_ext_postings ORDER BY id`
8. `SELECT id,index_id,field_id,namespace,gram_length,gram,documents FROM __gosqlite_ext_frequency ORDER BY id`
9. `SELECT id,index_id,entry_node,max_level,live_count,tombstone_count,next_node_id,training_state FROM __gosqlite_ext_ann_state ORDER BY id`
10. `SELECT id,index_id,node_id,content_rowid,live,level,original_vector,adjacency FROM __gosqlite_ext_ann_nodes ORDER BY id`
11. `SELECT id,index_id,content_rowid,node_id FROM __gosqlite_ext_ann_live ORDER BY id`
12. `SELECT id,index_id,list_id,centroid,member_count FROM __gosqlite_ext_ann_centroids ORDER BY id`
13. `SELECT id,index_id,list_id,content_rowid FROM __gosqlite_ext_ann_members ORDER BY id`

Canonical digest encoding carries stream ID, SQL and parameters, exact row/column count, per-cell storage-class tag, length, and bytes. Integers are signed int64 values; NULL is distinct; vectors/adjacency retain full BLOB bytes. Canonical frames/artifacts reject extra fields, noncanonical/duplicate keys, trailing bytes, bad extents and unknown schema. The native writer and pure model must use one schema or explicitly parity-test its wire mirror.

All three user streams must match independent literal/formula expectations. Decode each vector and compare every float32 component to the specified generator; checking only a vector count is insufficient. The shadow/schema streams are validated semantically at seed time, frozen before checkpoint, then compared **in full, including physical shadow row IDs and adjacency bytes**, on writer admission and independent reopen. A hash alone without retained bounded contents is insufficient for review.

Exact semantic assertions:

- Exactly three catalog records with the fixed names/source tables/methods; generation=1, needs_reindex=0, source_rows=7/180/128, exact normalized configuration, correct field column, and valid current source/schema binding. Bind all owned shadow table/index/trigger schema bytes; reject any unexpected user object or missing guard. Physical root pages may be fixture-generated, but must remain exactly the pre-checkpoint values within a case.
- Grams: independently enumerate all distinct ASCII substrings of lengths 1,2,3 for each non-NULL body in both `LIKE_RAW_V1` and `MATCH_CONFIG_V1`; empty string yields none. These lowercase ASCII inputs have identical token text in the two distinct namespaces. Require exactly **96 posting rows and 68 frequency rows**, each expected `(index,field,namespace,length,text,rowid)` once, exact per-token document count, no orphans. Source: `grams13/registry.go:Keys` and the ordinary grams checks. This independent tiny predicate needs no production tokenizer in the pure model.
- HNSW: 180 live source mappings and 180 nodes, zero tombstones, next_node_id=181; every source identity/vector has exactly one mapping to a live node with the same vector. Complete graph state and adjacency BLOBs equal the frozen C ledger; run actual CheckExtensionIndex to validate node identities, adjacency targets/layers, entry/max level, forward/reverse lookup and orphan counts. Do not equate a positive ANN counter with whole-graph integrity or claim every node is visited by one query.
- IVF: training_state=ready, live_count=128, exactly 4 centroids and 128 memberships, exactly one member per source. Decode persisted centroid and source components; independently compute squared L2 in float64 from their float32 values and choose the first lowest-distance list in list_id order, matching the ordinary independent membership oracle. Compare every membership and exact per-centroid member_count. Require all 128 members across all four lists; a one-list query alone is not this membership proof. No HNSW node/live rows may belong to the IVF index.
- `CheckExtensionIndex` succeeds individually for all three exact index names both before and after interruption. `DB.Check` then succeeds under the above quotas. Source arithmetic yields **Tables=12, ordinary Indexes=9, ExtensionIndexes=3, TableRows=979, IndexEntries=789, ReservedPages=0**. These count shadow tables and their ordinary lookup indexes, not just 315 user rows. Require these precise values; do not compare only extension count. Pages and FreePages must equal C's validated seed values; Pages is positive and at most 4096. PageReads must be positive and at most 1<<20; it need not be declared an OS-I/O metric or forced equal across adapters.

The count arithmetic is: nine shadow tables contain 3 catalog + 3 fields + 96 postings + 68 frequencies + 2 states + 180 graph nodes + 180 live mappings + 4 centroids + 128 memberships = 664 rows; add 315 user rows = 979. Ordinary indexes contain 3+96+68+2+180+180+4+128+128=789 keys. The schema also includes owned extension guard triggers; they are validated/frozen but are not tables or index entries.

### Real query paths, with independent reference answers

Execute these bounded queries before checkpoint and on the probe; retain complete hits, plan and stats. No EXPLAIN-only substitute, no ANN benchmark/report driver.

1. **Grams:** `db.SimilaritySearch(ctx,"docs_grams","body","abcd", SimilarityOptions{Threshold:0.6,Limit:2,Where:"docs.active=1"})`, plus the same call with ForceScan=true. Require exact hits row IDs 1,2, each score 2/3, and equality with the scan. Indexed plan Access=SEARCH, CandidateMode=UnionPostings, Exact=true, QueryTokens=3, generation=1 and nonempty config/tokenizer hashes; stats BaseRowFetches=3, Candidates=3, PostingKeysRead=7, PostingRangesRead=3, FilteredRows=1, ScoredRows=2, MatchedRows=2, ReturnedRows=2. These are the seven-row ordinary test's exact assertions. The numeric literal Where avoids an unrelated named-argument dependency.
2. **HNSW:** `db.VectorSearch(ctx,"hitems","embedding","[20,6,1]", VectorSearchOptions{Mode:VectorModeApproximate,Index:"hitems_hnsw",Limit:5})`; also exact default Mode with Limit=5. Require index=the named index, Access=SEARCH, Method=hnsw, Exact=false, vector_l2_ops, generation=1; positive node/edge/distance/rescore work, BaseRowFetches<180, five returned rows, ANNIdentityLookups=BaseRowFetches. Exact scan must visit 180 source rows and read no ANN nodes. Both results equal independently computed full-scan distances with row-ID ties; expected IDs are 20,19,18,17,23. Recompute each returned distance against its own source vector. Persist and compare complete results across the checkpoint. No approximate-recall guarantee beyond this fixed query/fixture.
3. **IVF:** same VectorSearch on iitems with query `[0,0,1]`, ModeApproximate, Index=iitems_ivf, Limit=5, default Probes=1. Compare full hits with the exact default full scan and independently scored source vectors; expected IDs 1..5. Require Method=ivfflat, Access=SEARCH, Exact=false, Lists=4, Probes=1, MaxProbes=4, EffectiveProbes=1, TrainingState=ready; CentroidReads=CentroidScores=4, ListsOpened=1, MemberKeysRead=BaseRowFetches=ExactRescores=IdentityLookups=32, Iterations=1, NodeReads=DistanceEvaluations=0. Do not use Probes=Lists: this implementation deliberately switches that option to an exact table scan, which would fail to establish the IVF path.

If the composed fixture fails one of these exact ordinary expectations, that is a concrete fixture/implementation issue to diagnose under later authorization. It must not cause automatic row-count growth, different seeds, weaker query assertions, a campaign, or a fabricated prior PASS.

## 6. Committed head, encrypted identities, and bounded copy/reopen

### Plain

Bind C to full main/WAL manifests and a clean committed WAL scan: page size, salt/checksum, FrameCount, DBSize, EndOffset, selected page directory, and complete logical ledger digest. All extents/counts are checked before allocations. The selected pages are copied by the real production code; the controller never writes a substitute main page, deletes a WAL, or replays a journal.

For partial-copy cases the original committed WAL must be byte-identical before/after the writer exit. For exclusive retirement/control the WAL is absent and main length is exactly C.Pages*4096. For both shared cases/control main/WAL/SHM are retained in the writer family; record their exact identities and prove the WAL body is unchanged. SHM's transient lock/readmark bytes need not remain byte-identical across a legitimate open/close; do not call it durable authority.

The plain probe uses `OpenContext` on a new copy with the same WALExclusive/WALShared setting, NoCreate=true, KeepWALOnClose=true, and the fixed finite options. It is a **writable-mode normal reopen**, not an asserted read-only Open. This permits the existing supported shared SHM initialization/reconstruction contract. It does not call Checkpoint, Commit, RecoverRollback, WALTailPublication, Normalize, Reindex or any repair. After successful probe, main and any existing WAL bytes remain as copied; shared SHM may be rewritten/initialized by the supported native open. An exclusive open can invalidate stale SHM; that permission is confined to the disposable probe copy and recorded, never applied to frozen evidence. A missing WAL after exclusive retirement is valid in mode 2 (`Session.OpenSession` contract); do not manufacture a replacement authority.

### Encrypted

Copy the full recognized family, including root, `.gse-lock`, bases, **WAL segment objects**, `.pending` and `.retained` roots. R5's layout-1 whitelist omits WAL segments and must not be reused unchanged. The exact segment name is `rootPath + ".gse-" + idString(header.FileID) + ".wal"` (`internal/encstore/wal_object.go:175`), and its header role must be FileWAL. Bases use the matching FileBase identity; pending/retained names bind FileRoot. Never accept an arbitrary filename prefix as sufficient. Reject plaintext `-wal/-shm/-journal`, symlinks, hardlinks, subdirectories, foreign entries, wrong public role/name bindings and oversized inventories.

Use one same raw test credential with fixed immutable per-role purposes: seed/create on original path, writer/open on trial path, probe/open on probe path. Each provider validates exact public operation/path/kind and releases/clears its one borrowed clone once; no key material is serialized. No second “new key”, old/new probe pair, password/KDF matrix, retained-root promotion, archive, Restore, or rekey-specific nonce facility is added.

Before arm: authenticated old Info has layout2/mode EncryptionWAL, sequence4, one segment, correct DBID/page geometry, and frozen old HeadCommitID. The root observer binds exact old-root hash/header across all cuts; candidate header has the same complete Epoch, fresh FileID, same geometry, sequence old+1, and ParentCommitID equal to the **old authenticated HeadCommitID**. Both old/candidate bytes have bounded valid public header extents. They are already authenticated by production before observation; public decoding alone is not an authentication claim.

Probe opens a distinct copied family with the same credential, ReadOnly=true, NoCreate=true, EncryptionWAL. `VerifyEncrypted` must authenticate the exact observed selected root hash and header. Before-rename requires the complete old Info and old root. After-rename/dirsync/control requires candidate root hash/header, same DBID/Epoch, sequence5, and zero active WAL segments/frames/bytes. Its HeadCommitID must be the authenticated new base head, different from old; it is **not** compared to root SHA256. The production verifier binds the candidate manifest to its selected base, so a new unauthenticated “parse decrypted manifest” hook is unnecessary. Every successful encrypted probe also passes the complete C ledger and all index checks.

No plaintext logical page-hash equality is claimed for encrypted heads: the existing public API gives authenticated root/head identity plus full semantic SQL/index/Check evidence, not arbitrary plaintext page access. Do not silently convert that limitation into either a PASS claim or a new R1–R6 requirement.

### Private copies and original preservation

Controller owns newly created 0700 run subdirectories: original, trial, evidence/post-exit, probe, and control. Files are exclusive-created 0600, regular, one-link, exact owner, canonical ancestor path; verify fd/path identity, size and hash before/after reads/copies. All copies have distinct dev/inode pairs from source and each other. Preserve the entire recognized family; no “just copy main”. New destination file/dir syncs are allowed, but **never Sync, open as a database, repair, rename, truncate, or overwrite original/trial/post-exit evidence after the writer**. Recheck their full manifests at the end.

Only after the parent's actual writer Wait and terminal event-pipe EOF may it freeze/copy the exited trial. The single probe uses its private mutable copy. Probe errors cannot trigger another profile, fallback, retry, or reopen of originals. Original/candidate ciphertext retained history is inventoried, not promoted.

## 7. One controller, causal protocol, and owners

Reuse R5's **reviewed design**, not its concrete six-case API/model. Fixed roots:

- `TestManualCheckpointRestartController`
- `TestManualCheckpointRestartWriter`
- `TestManualCheckpointRestartProbe`

One admission selects one ten-case ID and a fresh retained run root; case determines authority, filename and profile. Closed roles have distinct generation values. Parent binds complete source image, approved compile-only receipt, compiler, binary bytes and actual `/proc/self/exe`/same-inode spawn path. Child flags are exact anchored root, count1, parallel1, shuffle off, timeout0; environment is fixed allowlist with empty GOFLAGS and the new manual admission/binding/challenge fields. No shell, PATH executable lookup, arbitrary test selector, CommandContext, PID capability, Kill, Signal, exec replacement, or child-spawning child.

One parent-created control pipe and one event pipe become fd3/fd4 in a child. Frame binding includes schema/trial/source/binary/case/profile/fixture/role/generation/challenge/sequence. Grants echo the exact event hash plus identity/point. Unknown fields, replay, reordering, duplicate cut, wrong profile, wrong head, trailing frames or a mismatched grant abort the native role and cannot produce success. No stdout-text matching is process evidence.

Trace:

1. Parent admits, prepares/verifies/closes seed C and durable committed-head receipt, copies trial, starts writer once.
2. Writer role-ready, parent grant, Open and full C/head verification with every Rows closed; checkpoint-ready, parent verifies exact seed binding then checkpoint grant.
3. Context armed only for the immediately adjacent public DB.Checkpoint. Observations follow the selected authority's exact ordered points. Non-target point gets continue; target gets exit and the child's bridge self-exits with fixed code86. Invalid protocol uses code87 and is failure. No deferred DB.Close/rollback/checkpoint runs on target self-exit.
4. Control traverses all points, captures exact public nil, closes once with KeepWALOnClose, verifies pending registries empty, emits complete control result, receives done and exits normally.
5. Parent's one owned `Cmd.Wait` returns actual ProcessState: expected code86 for an interruption or 0 for control, exited and not signaled, exact known original exit error where applicable, plus terminal event-pipe EOF. Then retire pipe/process owners once. The commit receipt predates checkpoint; interrupted cases cannot acquire a public-checkpoint-nil or checkpoint ACK label.
6. Parent freezes trial, creates probe copy, starts probe once; ready/grant precedes its one public open. Probe returns full ledger/head/owner result, closes once, exits naturally; parent consumes its one actual Wait and terminal EOF before accepting result.
7. Parent rechecks frozen manifests and writes bounded observations with separate `SourceModelConsistent`, `PublicCheckpointReturned`, `ActualWaitObserved`, `CommittedHeadRecovered` fields. `PhysicalValidated` remains false for the source/model artifact and for same-kernel observations that do not establish power-loss qualification. No generic `PASS` bit can combine these distinct claims.

All concrete file/DB/Rows/provider/channel/process capabilities are captured before testing error handling. A public object returned non-nil together with error still has an owner. Parent/child owner dependencies block parent retirement while a child is live/unknown. One close attempt only; the first cause is retained. Check all three public pending registries, `PendingPlaintextCleanups`, `PendingCloseCleanups`, `PendingEncryptedCleanups`, as applicable before/after native work. No retry/drain API, reset, or success conversion. A process-abrupt writer has DB CloseCalls=0; actual OS process exit is recorded, not invented orderly DB closure. Seed/probe/control require one clean DB.Close and their finite owners retired.

If a timer/transport/Start/Wait error occurs, preserve the complete error object, frame log and owners; no dependent copy/probe. If Wait is pending, the controller stays in an unresolved-child hold with its actual Wait channel retained, not `t.Fatal` returning to testing.main and abandoning the process. A later actual Wait may be recorded only as late disposition, not as repair of the failed run. A Wait result without ProcessState stays UNKNOWN and passively holds; there is no second Wait. This is the source-review-fixed R5 owner/protocol pattern.

## 8. Finite model and source guards

Pure model inputs are bounded values only, including synthetic complete ledgers, artifact identities and explicit event/owner receipts. It cannot create a database, call the native bridge, execute a child, infer actual Sync/Wait, or produce physical validation. Its successful answer means only “these supplied values satisfy this frozen finite contract.”

Proposed exact pure test roots (new names, not claims they exist yet):

- TestCheckpointRestartTenCases
- TestCheckpointRestartAuthorityCuts
- TestCheckpointRestartCommittedHeadCausality
- TestCheckpointRestartTransportBinding
- TestCheckpointRestartOwnerWaitAndUnknown
- TestCheckpointRestartPrivateFamilyCopies
- TestCheckpointRestartEncryptedSameEpoch
- TestCheckpointRestartNeverPhysicalPass
- TestCheckpointExtensionFixtureRows
- TestCheckpointExtensionGramsLedger
- TestCheckpointExtensionGraphMembershipLedger
- TestCheckpointExtensionQueryPathsAndCheck

Positive seeds cover exactly ten cases. Finite negative edits cover each omitted/reordered cut; stale B versus C; missing row/index/posting/node/edge/member; duplicated/orphan membership; wrong centroid assignment; one-list-only membership evidence; fake SEARCH/EXPLAIN/fallback; wrong rescored source vector; incorrect Check totals; epoch change/root-hash-as-parent error; unsupported copied-family entry/alias; forged commit ACK/public return; unowned/repeated/missing Wait; close retry and pending owners; absent EOF/extra frames; limits/truncation/noncanonical schema. Keep failures finite and enumerated, without fuzz/campaign generation.

Proposed exact semantic-AST/source test roots:

- TestCheckpointRestartGuardInventoryAndGate
- TestCheckpointRestartGuardProductionOrder
- TestCheckpointRestartGuardObserverPurpose
- TestCheckpointRestartGuardPublicEntryAndCommitReceipt
- TestCheckpointRestartGuardProcessOwnership
- TestCheckpointRestartGuardFullExtensionLedger
- TestCheckpointRestartGuardPrivateCopiesAndProbe
- TestCheckpointRestartGuardDefaultAndIntegration

Guard all current Go source for protected names/import consumers, including excluded-tag copies. Exact owned files, tags, package/import sets, concrete permitted effects, fixed role roots, process flags/env, pipe descriptors, context arm callsite, ordinary default stubs and native-to-model schema are frozen. Production adjacency mutants move a real operation across a seam or substitute wrong point/authority and must fail. Semantic mutants should recompute byte pins so stale hashes alone do not satisfy the safety check. Review the complete new native/observer/helper call closure and changed main/oracle functions; do not claim the scanner proves arbitrary Go program safety. Never whitelist the whole manual tag or all process calls.

Default import closure must exclude `manual_linux.go`, both native adapters and all three role roots. Non-Linux must select only inert stubs. A5/R5 guards and roots retain their exact previous scope. Shared `publish.go` source-pin changes require the R5 owner’s explicit integrated-source review, not automatic hash refresh. No R5 purpose or six-case acceptance is broadened.

## 9. Exact later validation selectors, not execution now

These are proposed commands/selectors for a separately authorized source freeze. They were **not run** and do not authorize native execution.

Pure model selector:

    go test ./internal/testkit/checkpointrestart -run '^(TestCheckpointRestartTenCases|TestCheckpointRestartAuthorityCuts|TestCheckpointRestartCommittedHeadCausality|TestCheckpointRestartTransportBinding|TestCheckpointRestartOwnerWaitAndUnknown|TestCheckpointRestartPrivateFamilyCopies|TestCheckpointRestartEncryptedSameEpoch|TestCheckpointRestartNeverPhysicalPass|TestCheckpointExtensionFixtureRows|TestCheckpointExtensionGramsLedger|TestCheckpointExtensionGraphMembershipLedger|TestCheckpointExtensionQueryPathsAndCheck)$' -count=1

AST selector:

    go test ./internal/testscope -run '^(TestCheckpointRestartGuardInventoryAndGate|TestCheckpointRestartGuardProductionOrder|TestCheckpointRestartGuardObserverPurpose|TestCheckpointRestartGuardPublicEntryAndCommitReceipt|TestCheckpointRestartGuardProcessOwnership|TestCheckpointRestartGuardFullExtensionLedger|TestCheckpointRestartGuardPrivateCopiesAndProbe|TestCheckpointRestartGuardDefaultAndIntegration)$' -count=1

Source selection (metadata only, not launch): Linux default and Linux with exactly `manual_checkpoint_restart`, over `./internal/pager ./internal/encstore ./internal/testkit/checkpointrestart ./sqlite`; a non-Linux target selects defaults. Check the existing R5-only selection is unchanged, then the combined `manual_checkpoint_restart,manual_rekey_interruption` selection solely for adjacent-observer composition if specifically authorized. No all-profile/native matrix.

Compile-only: `go test -c -tags=manual_checkpoint_restart -o <new retained output>/checkpoint-restart.test ./sqlite`. Separately compile its ordinary counterpart if needed to establish absent native symbols. If R5 is integrated, a combined-tag compile-only binary may verify coexistence; do not launch it. Bind exact compiler/source/tag/environment/output hashes in the receipt. Do not use `-run=^$` as a substitute for compile-only, execute the resulting binary even to list tests, invoke an existing native controller, or schedule any CI/native run.

After guard integration, the existing source-only testscope scanner and affected old exact guard selectors may be authorized to verify preservation. No blanket whole-repository test/campaign is added here. Source model/race/AST/compile status stays separate from actual fixture, process exit, checkpoint, reopen and filesystem persistence.

## 10. Concrete gaps and stopping condition

This proposal resolves the design choices without pretending that its code exists:

1. Implement the ten-case common bridge/controller and full 315-row ledger; no further case/profile selection remains open.
2. Before source freeze, implement the verified layout-2 `.wal` segment naming and all public-header/name relations in the family helper, and review the composed Tx/schema/Check count contract in source. The 96/68 posting/frequency and 979/789 Check totals above are independent source-derived arithmetic, not measured output.
3. Use the actual integrated baseline (R5 may be integrated meanwhile), preserve its three calls/contract, and independently re-review affected whole-source/main pins. No automatic pin update or guard bypass.
4. Freeze implementation-specific bounded structs, source manifest, exact import/call closure and native-to-pure frame parity. The proposed source organization may be compacted without changing cases or effects; do not generalize it into an arbitrary process/fault library.
5. Separately authorized pure/AST/source-selection/compile checks establish their own actual terminal results. The composed fixture, real interruption, normal reopen, shared SHM behavior on this exact fixture, and all native persistence claims remain NOT_RUN until specifically authorized and actually observed.

Finite R3/R4 code closure requires source plus the expected reviewed finite checks, not physical qualification. A concrete failure may justify a narrow correction; lack of a power-loss run, untested layout-3 maintenance, or no HNSW-wide performance report is not permission to expand the locked R1–R6 scope.
