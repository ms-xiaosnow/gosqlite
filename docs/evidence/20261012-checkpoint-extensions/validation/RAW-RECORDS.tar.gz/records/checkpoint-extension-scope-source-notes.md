# R3 / R4: source map for the next finite design

2026-10-12. Read-only source observations, not implementation or validation. Current main 01c63e6f8fb3d9e196afe2f42a163eb3eac4ad5a. The R1–R6 boundary is fixed; these notes do not add requirements, cases, permissions, or physical execution.

## Actual authority paths observed

- `internal/pager/checkpoint.go`, `Session.checkpointLocked`: exclusive session, active transaction refused; protection images precede safety-critical work; WAL Sync, sorted selected page copies, main Truncate, main Sync, one WAL close, WAL unlink, stale SHM unlink, directory Sync, in-memory refresh. Once physical work starts, errors poison the session. A committed WAL remains authority until main synchronization and retirement. A useful finite cut must distinguish partial main copy from WAL retirement; tail publication is not this protocol.
- `internal/pager/shared_checkpoint.go`, `SharedSession.checkpointLocked`: checkpoint/write/read0 range locks, frozen header/readmarks, generation recheck, attempted backfill, WAL Sync, selected safe page copies, optional Truncate, main Sync, SetBackfill. WAL/SHM inodes remain. Partial main copy and committed backfill are different states. A cold read-only Open is not a valid universal probe, because this project's read-only contract requires initialized live SHM. Any fresh writable probe must use its explicit supported contract on an independent copy, without claiming main-only authority.
- `internal/encstore/publish.go`, `Store.Checkpoint`: shared maintenance when applicable; Check/context/CopyBudget/Verify; `Publish(..., target=nil)` creates an immutable base and root. This preserves the credential/epoch contract, unlike Rekey's target. The same root-publication ordering is relevant, but the R5 OLD/NEW credential and six-case contract must not be silently broadened.
- Public entry: `sqlite.DB.Checkpoint` exists. The later design must verify its precise owner/transaction contract, rather than bypassing it with storage internals.

## Finite design questions, not new acceptance scope

R3 needs the different authority paths already named by the accepted finite checklist. Prefer only necessary interruption cuts, one explicit bounded fixture, and direct preservation of the committed ledger. Source-only hooks must be void/default-no-op and preserve production call/error order. Reuse the already reviewed process-lifecycle patterns and fixes where suitable; do not reopen A5's fixed plain rollback model or introduce an arbitrary offset/profile/controller framework.

R4 can potentially reuse R3's finite controller and add a small explicit extension-index ledger, rather than creating another process framework. Check whether one fixed combined fixture can contain grams posting, HNSW graph and IVF membership with bounded pages/events. Exact SQL support, index-verification APIs, table/row/hash/query expectations and quotas must come from existing ordinary tests. This is only a design preference; it is not an assertion that the fixture or controller already exists.

Do not invoke the old ANN V4 reporting/measurement chain or a campaign. R4 checks normal finite index/data consistency after a separately gated interruption; source review must identify its exact independent call closure. Actual checkpoint interruption, process exit and recovery remain NOT_RUN. If the supported API cannot establish an asserted state, document the code gap rather than inventing a PASS or silently accepting any openable file.

No Go, parser executable, compiler, tests, databases, fixtures, checkpoint or process controller was executed for these observations. No production source was changed.
