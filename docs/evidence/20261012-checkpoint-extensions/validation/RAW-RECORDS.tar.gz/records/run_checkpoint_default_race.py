"""Finite R3/R4 validation recorder. Preparation does not execute this file.
Run only after authorization and integration, with --source-identity PATH.
The tagged sqlite test image is compiled and inspected, never executed.
"""
import argparse
import collections
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

R = Path(__file__).resolve().parent
W = R / 'gosqlite'
E = R / 'checkpoint-default-race-validation'
OLD_E = R / 'checkpoint-focused-validation'
F = R / 'checkpoint-format'
GO = R / 'toolchains/go1.27.2/bin/go'
FMT = GO.with_name('gofmt')
GO_HASH = '548d3c32f83fa81152f543eb1526be7884cfe0526eb5e9ce29d3eca14786e7e0'
FMT_HASH = '5583dbb3339147fee7cdb067eb3cd4a50015b48c27084377f49d93833aa4ad77'
GOPATH = R / 'toolchains/gopath'
ENV = dict(PATH=str(GO.parent)+':/usr/bin:/bin', GOMAXPROCS='2', GOENV='off',
    GO111MODULE='on', GOWORK='off', GOTOOLCHAIN='local', GOPROXY='off',
    GOSUMDB='off', GOAUTH='off', GOFLAGS='', GOEXPERIMENT='', GOFIPS140='off',
    GODEBUG='', GOCACHEPROG='', GOCOVERDIR='', GORACE='', GOTELEMETRY='off',
    GOROOT=str(GO.parent.parent), GOPATH=str(GOPATH), GOMODCACHE=str(GOPATH/'pkg/mod'),
    GOCACHE=str(R/'go-cache'), TMPDIR='/tmp', GOTMPDIR='', GOOS='linux',
    GOARCH='amd64', GOAMD64='v1', CGO_ENABLED='0', LC_ALL='C', LANG='C', TZ='UTC')
TEST_FLAGS=['test','-json','-mod=readonly','-buildvcs=false','-p=1','-vet=off','-count=1','-parallel=1','-timeout=0']
NM_ROW=re.compile(r'(?:(?P<address>[0-9A-Fa-f]+)[ \t]+)?(?P<type>[A-Za-z?_])[ \t]+(?P<symbol>\S(?:[^\r\n]*\S)?)')

MANIFEST_HASH = '112820790a2727e1b8d30f801ab0f7ae0fcb06e37e5f28a0c73d63ab1e7b2b94'
PLAN_HASH = '9b3b31d013383605d4b0c2f584a3fc87cf3fde306f3b8d5f8571f832bac82921'
HELPER_HASH = 'ddb2d3825e16d551783a4bb1f08b437d1eda14cef02a882f651323605bd6c27e'
MODULE = 'github.com/ms-xiaosnow/gosqlite/'
PACKAGES = ['./internal/pager', './internal/encstore', './internal/testkit/checkpointrestart', './internal/testscope', './sqlite']
MANUAL_ROOTS = {'TestManualCheckpointRestartController', 'TestManualCheckpointRestartWriter', 'TestManualCheckpointRestartProbe'}
HOOKS = ['inspectCheckpointRestartSource(path, raw)', 'inspectCheckpointRestartContracts(".")']
IMAGE = E / 'checkpoint-sqlite.test'
REQUIRED_SOURCES = {'docs/testing/checkpoint-restart-manual-zh.md': '297d6b94908880fb56274e7d743a5c0374892a9b8c63bebf7a0a465e9f5067b7', 'internal/encstore/checkpoint_observation.go': '53e8e9d5f624dd5c5048451f39d6100d84e552b964b54734e397e0b203418f2b', 'internal/encstore/checkpoint_observation_default.go': '9207c7cd19343bc0bd7e49741015288bc5e819303c7b1bfc7252085c7581ec99', 'internal/encstore/checkpoint_restart_manual_linux.go': 'ff528903720dba67a17814120da9d066749c5641fab4b4e1a76bb09c47b0bd8c', 'internal/encstore/publish.go': '76b24327571e519ed8a59661fd552571d4d4ae6ef19bb9bb2e1c680d86bcc86b', 'internal/pager/checkpoint.go': '3b70e940343ccdd2a02bb88d086dc3304364f6c842d6ef985645c5ebc3f2a36f', 'internal/pager/checkpoint_observation.go': '4283c5c8cda005988f65c018cb79de16887fa9947e01c280ecf4ccd20ba11136', 'internal/pager/checkpoint_observation_default.go': '7d9af5a08acad66e20fc39e753e37f45d628a7c5a052c8d6458b321d4751bb02', 'internal/pager/checkpoint_restart_manual_linux.go': 'eb6a14c2ac23c55e2063b3154c5002abb02ec5c879140d2f657e521b2e380a65', 'internal/pager/shared_checkpoint.go': 'a32ba18f1f7e365cbdbc7aa5bb1a91063254d238016117c2298bce242906940d', 'internal/testkit/checkpointrestart/contract.go': '42281d899772be55222137744b0638b4c073e7d96772367604a9553eaf1fff8a', 'internal/testkit/checkpointrestart/contract_test.go': 'f5d74cd9a812d5210f7898aaf207f3002cd4504f2813ffb46401fa2bd935c565', 'internal/testkit/checkpointrestart/extension_ledger.go': '37c8de96e7140e5d6702b3fce10d8cb78fdaab29617c229c23947a2b2f9c4afa', 'internal/testkit/checkpointrestart/extension_ledger_test.go': 'b419fc94a3178a847b53a114d4a66baa647dc5f61dd98d24af4df943c718c5d3', 'internal/testkit/checkpointrestart/manual_linux.go': 'c287ed91ff456c29a02ed00fbe7bdc72e127ea0a55995d6f0bfffa4659955542', 'internal/testscope/checkpoint_restart.go': 'f9d6f0843e50a745922b223b6f11e1dd557e0acd17c94cfb53ea2811951811c9', 'internal/testscope/checkpoint_restart_test.go': '34fe14791bba5cd2118ccb21d36fd0d20e4b4ff63335464f813db64cdb9150d6', 'internal/testscope/main.go': '9d29dda532e851dd0fa2211473a5abb24309f798a849483c7efca09a7a3a058f', 'internal/testscope/oracle_startup.go': 'f7d7f6f02e886dfe057a4494564093f78a7644dffe2fa4c41fafa2929227edda', 'internal/testscope/readonly_wal_manual.go': '81e4a67d1d142e29e530c7f7ce90e93723f4aa3ea2152d596e0e8f7c9566417d', 'internal/testscope/readonly_wal_manual_test.go': 'feb4257d9fd68a501c0289242eeb199aa8ebca7e3ebae197aff7cbe7814770da', 'internal/testscope/rekey_interruption.go': '851d5b344d3e975e2136ed227d91906753b4b8a651a29c1130d56e0f5d09ab14', 'internal/testscope/rekey_interruption_test.go': '4e58cb737ad468ca0a43861752a6549ebb117e4858c1b7fd1316430bc92d14f0', 'sqlite/checkpoint_restart_manual_linux_test.go': 'e14ba4a5ea3bacdf0d9f124e97dedde529db4c980628de8968b1e435d3abaed8', 'internal/testscope/wal_tail_publication.go': '4f0c385c993c03069ae3f6a2a38bf317c0c590f464ae280f13799b455f0b88ee', 'internal/testscope/encryption_upgrade_manual.go': 'dcd6ca1ce5d8ea5c13e8ed39436e9e17c2233110365dc09eac6e8e255d9d96fd', 'internal/testscope/encrypted_root_negative.go': '6402d12cd0e7856c203ce616f38ade96c90c55602da3371e9b086fa93a994cdb', 'internal/testscope/rollback_fault_test.go': 'c5702b519be67955c77b3ea3956173193f035c0018b70687bd35710c83acec60', 'internal/testscope/rollback_fault_sql_test.go': 'b9c98b33cb733f184db00a64902328a45dd5df8308b6ec1ee82fd5434789155d', 'internal/testscope/rollback_restart_test.go': 'ddbbc38db85131294b5465b86baf5ba87fd19f9b109fd8f970c605b52bd53af2'}
HEALTHY_SOURCES = {'internal/pager/shared_session_test.go': 'cee804bf7abc89c46af79be103ec89be4a67c371d4d302703116cf660d39cedd', 'sqlite/wal_test.go': 'ed184c95a2d846532ee70f7bfd7e41dba0807b4be118a5563ef64bb0e8b38bd8', 'sqlite/encryption_shared_review_test.go': '7f4a21889a9c6e2dba6b234433f51ddd159386cbf2acc2bc539deb9acb8792f1'}
FORMAT_SOURCES = ['internal/encstore/checkpoint_observation.go', 'internal/encstore/checkpoint_observation_default.go', 'internal/encstore/checkpoint_restart_manual_linux.go', 'internal/encstore/publish.go', 'internal/pager/checkpoint.go', 'internal/pager/checkpoint_observation.go', 'internal/pager/checkpoint_observation_default.go', 'internal/pager/checkpoint_restart_manual_linux.go', 'internal/pager/shared_checkpoint.go', 'internal/testkit/checkpointrestart/contract.go', 'internal/testkit/checkpointrestart/contract_test.go', 'internal/testkit/checkpointrestart/extension_ledger.go', 'internal/testkit/checkpointrestart/extension_ledger_test.go', 'internal/testkit/checkpointrestart/manual_linux.go', 'internal/testscope/checkpoint_restart.go', 'internal/testscope/checkpoint_restart_test.go', 'internal/testscope/main.go', 'internal/testscope/oracle_startup.go', 'internal/testscope/readonly_wal_manual.go', 'internal/testscope/readonly_wal_manual_test.go', 'internal/testscope/rekey_interruption.go', 'internal/testscope/rekey_interruption_test.go', 'sqlite/checkpoint_restart_manual_linux_test.go', 'internal/testscope/wal_tail_publication.go', 'internal/testscope/encryption_upgrade_manual.go', 'internal/testscope/encrypted_root_negative.go', 'internal/testscope/rollback_fault_test.go', 'internal/testscope/rollback_fault_sql_test.go', 'internal/testscope/rollback_restart_test.go']
ROOT_GROUPS = {'05_pure_models': {'./internal/testkit/checkpointrestart': ['TestCheckpointRestartTenCases', 'TestCheckpointRestartAuthorityCuts', 'TestCheckpointRestartCommittedHeadCausality', 'TestCheckpointRestartTransportBinding', 'TestCheckpointRestartOwnerWaitAndUnknown', 'TestCheckpointRestartPrivateFamilyCopies', 'TestCheckpointRestartEncryptedSameEpoch', 'TestCheckpointRestartNeverPhysicalPass', 'TestCheckpointExtensionFixtureRows', 'TestCheckpointExtensionGramsLedger', 'TestCheckpointExtensionGraphMembershipLedger', 'TestCheckpointExtensionQueryPathsAndCheck']}, '06_ast_guards': {'./internal/testscope': ['TestCheckpointRestartGuardInventoryAndGate', 'TestCheckpointRestartGuardProductionOrder', 'TestCheckpointRestartGuardObserverPurpose', 'TestCheckpointRestartGuardPublicEntryAndCommitReceipt', 'TestCheckpointRestartGuardProcessOwnership', 'TestCheckpointRestartGuardFullExtensionLedger', 'TestCheckpointRestartGuardPrivateCopiesAndProbe', 'TestCheckpointRestartGuardDefaultAndIntegration', 'TestRekeyGuardInventoryGate', 'TestRekeyGuardPublicationOrder', 'TestRekeyGuardObserverIsolation', 'TestRekeyGuardPublicReturnACK', 'TestRekeyGuardProcessOwnership', 'TestRekeyGuardProbeLedger', 'TestRekeyGuardIntegrationDefault', 'TestReadOnlyWALManualSourceContract', 'TestReadOnlyWALManualDefaultExclusion', 'TestReadOnlyWALManualWholeRootInventory', 'TestReadOnlyWALManualGateAndProfileMutations', 'TestReadOnlyWALManualEffectBoundaryMutations', 'TestReadOnlyWALManualOwnershipMutations', 'TestReadOnlyWALManualPureClosureMutations', 'TestOracleSourceConstructorGuard', 'TestOracleSourceImportAndMutationGuard', 'TestOracleSourceFactoryLiteralGuard', 'TestOracleSourceNativeExceptionGuard', 'TestOracleSourcePathScope', 'TestScopeSourceReferenceGuard', 'TestEncryptedRootFiniteStructure', 'TestEncryptedRootFalsePassSourcesEvenWhenRepinned', 'TestEncryptedRootWholeSourceAndCapabilityBoundary', 'TestEncryptedRootPinsRequireIndependentRelease', 'TestFormatUpgradeMainKeepsExistingPolicies', 'TestWALPublicationGuardFixedSourceAndWiring', 'TestRollbackFaultGuardWiringPreservesPriorPolicies', 'TestRollbackFaultSQLWiringAndMainReviewHold', 'TestRollbackRestartWiringPreservesAllPoliciesAndReviewHold', 'TestRollbackRestartOracleExceptionRequiresCompletePinnedNativeClosure']}, '07_healthy_pager': {'./internal/pager': ['TestSharedWALSnapshotsPromotionAndCheckpoint']}, '08_healthy_sqlite': {'./sqlite': ['TestNativeWALConnectionLifecycle', 'TestReviewEncryptionSharedLatestCheckpointMetadata']}}
LISTS = {
 '02_list_linux_default': {'goos':'linux', 'manual':False, 'checkpoint_selected':False},
 '03_list_linux_manual': {'goos':'linux', 'manual':True, 'checkpoint_selected':True},
 '04_list_nonlinux_fallback': {'goos':'darwin', 'manual':True, 'checkpoint_selected':False},
}
COMMANDS = [('01_format', [str(FMT), '-l', *FORMAT_SOURCES], ENV)]
for name, selection in LISTS.items():
    flags = ['-tags=manual_checkpoint_restart'] if selection['manual'] else []
    COMMANDS.append((name, [str(GO), 'list', '-json', '-mod=readonly', '-buildvcs=false', '-p=1', *flags, *PACKAGES], dict(ENV, GOOS=selection['goos'])))
for name, groups in ROOT_GROUPS.items():
    selector = '^(' + '|'.join(root for roots in groups.values() for root in roots) + ')$'
    COMMANDS.append((name, [str(GO), *TEST_FLAGS, '-run', selector, *groups], ENV))
COMMANDS += [
 ('09_sourceguard', [str(GO), 'run', '-mod=readonly', '-buildvcs=false', '-p=1', './internal/testscope'], ENV),
 ('10_compile_manual_sqlite', [str(GO), 'test', '-mod=readonly', '-buildvcs=false', '-p=1', '-vet=off', '-c', '-tags=manual_checkpoint_restart', '-o', str(IMAGE), './sqlite'], ENV),
 ('11_nm_manual_sqlite', [str(GO), 'tool', 'nm', str(IMAGE)], ENV),
]

# Reuse unchanged selected file/root sets from the first run. The only source
# correction removes an unused import; no tag/file/root list changed.
COMMANDS = [(n, ([str(FMT), '-l', 'internal/testkit/checkpointrestart/contract.go', 'internal/testscope/checkpoint_restart.go'] if n == '01_format' else a), e) for n,a,e in COMMANDS if n not in LISTS]

# Supplemental race only: the new default no-op seams are the changed shipping closure.
ROOT_GROUPS={'07_healthy_race':{'./internal/pager':['TestSharedWALSnapshotsPromotionAndCheckpoint'],'./sqlite':['TestNativeWALConnectionLifecycle','TestReviewEncryptionSharedLatestCheckpointMetadata']}}
selector='^('+'|'.join(n for ns in ROOT_GROUPS['07_healthy_race'].values() for n in ns)+')$'
COMMANDS=[('07_healthy_race',[str(GO),*TEST_FLAGS,'-race','-run',selector,*ROOT_GROUPS['07_healthy_race']],dict(ENV,CGO_ENABLED='1',CC='/usr/bin/gcc',CXX='/usr/bin/g++'))]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (E/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

def snapshot():
    names = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=W).decode().split('\0')
    return {name:{'bytes':(W/name).stat().st_size,'sha256':sha(W/name),
        'git_mode':'100755' if (W/name).stat().st_mode & 0o111 else '100644'}
        for name in sorted(set(names)) if name}

def resources():
    out = {'utc':now(),'paths':{},'qualified':True}
    for path, minimum in [(R,2*1024**3),(Path('/tmp'),1024**3)]:
        s = os.statvfs(path)
        entry = {'available_bytes':s.f_bavail*s.f_frsize,'available_inodes':s.f_favail,'minimum_bytes':minimum}
        out['paths'][str(path)] = entry
        out['qualified'] &= entry['available_bytes'] >= minimum and entry['available_inodes'] >= 10000
    return out

def tests(stdout, expected_packages):
    roots = collections.defaultdict(set)
    terminals = collections.Counter()
    outcomes = collections.Counter()
    package_pass = set()
    for line in stdout.splitlines():
        event = json.loads(line)
        action, package, name = event.get('Action'),event.get('Package'),event.get('Test')
        if action == 'run' and name and '/' not in name: roots[package].add(name)
        if action in ('pass','fail','skip'):
            if name:
                terminals[(package,action)] += 1
                outcomes[(package,name)] += 1
            elif action == 'pass': package_pass.add(package)
    assert package_pass == {'github.com/ms-xiaosnow/gosqlite/'+x[2:] for x in expected_packages}
    assert all(n == 1 for n in outcomes.values()), 'duplicate test terminal events'
    assert all(action == 'pass' for (_,action) in terminals), 'test FAIL or SKIP'
    assert all(roots.values()) and len(roots)==len(expected_packages), 'empty package selection'
    return {p:{'roots':sorted(names),'root_count':len(names),'named_pass':terminals[(p,'pass')],
        'child_pass':terminals[(p,'pass')]-len(names),'fail':terminals[(p,'fail')],'skip':terminals[(p,'skip')]}
        for p,names in roots.items()}

def selections(stdout, key):
    """Same selected-source root inventory as the prior recorder, for five packages."""
    decoder = json.JSONDecoder()
    packages = {}
    while stdout.strip():
        package, end = decoder.raw_decode(stdout.lstrip())
        stdout = stdout.lstrip()[end:]
        assert 'Error' not in package and not package.get('Incomplete'), package.get('Error')
        path = './' + package['ImportPath'].removeprefix(MODULE)
        assert path in PACKAGES and path not in packages, ('unexpected or duplicate package', path)
        assert Path(package['Dir']).resolve() == (W/path[2:]).resolve()
        assert not package.get('CgoFiles'), ('unexpected cgo selection', path)
        fields = {field: package.get(field, []) for field in ('GoFiles', 'TestGoFiles', 'XTestGoFiles')}
        selected = set().union(*map(set, fields.values()))
        roots = set()
        for field, suffix in [('TestGoFiles', ''), ('XTestGoFiles', '_test')]:
            for filename in fields[field]:
                assert Path(filename).name == filename
                body = (W/path[2:]/filename).read_text()
                for root in re.findall(r'^func ((?:Test|Fuzz|Example)[A-Za-z0-9_]*)\(', body, re.M):
                    roots.add(package['ImportPath'] + suffix + '.' + root)
        wanted_roles = MANUAL_ROOTS if path == './sqlite' and LISTS[key]['checkpoint_selected'] else set()
        roles = {root.rsplit('.', 1)[1] for root in roots if '.TestManual' in root}
        assert roles == wanted_roles, ('manual role difference', path, roles, wanted_roles)
        # Reject every other positive manual capability gate, including old R2/R5 paths.
        for filename in selected:
            first = (W/path[2:]/filename).read_text().splitlines()[0]
            if first.startswith('//go:build'):
                positive_tags = set(re.findall(r'(?<!!)\bmanual_[A-Za-z0-9_]+', first))
                allowed = {'manual_checkpoint_restart'} if LISTS[key]['checkpoint_selected'] else set()
                assert positive_tags <= allowed, ('unexpected manual selected source', path, filename, first)
        if path in ('./internal/pager', './internal/encstore'):
            manual = LISTS[key]['checkpoint_selected']
            assert ('checkpoint_restart_manual_linux.go' in selected) == manual
            assert ('checkpoint_observation_default.go' in selected) == (not manual)
            assert 'checkpoint_observation.go' in selected
        if path == './internal/pager':
            assert 'rollback_io_default.go' in selected and 'rollback_io_manual_linux.go' not in selected
        if path == './internal/encstore':
            assert 'rekey_observation_default.go' in selected and 'rekey_interruption_manual_linux.go' not in selected
        if path == './internal/testkit/checkpointrestart':
            assert ('manual_linux.go' in selected) == LISTS[key]['checkpoint_selected']
        if path == './sqlite':
            assert ('checkpoint_restart_manual_linux_test.go' in selected) == LISTS[key]['checkpoint_selected']
        packages[path] = {'roots': sorted(roots), 'manual_roles': sorted(roles), 'package': package}
    assert set(packages) == set(PACKAGES), 'missing go-list package'
    if key == '03_list_linux_manual':
        default = json.loads((E/'02_list_linux_default.result.json').read_text())['selection']['packages']
        deltas = {
            './internal/pager': ({'checkpoint_restart_manual_linux.go'}, {'checkpoint_observation_default.go'}),
            './internal/encstore': ({'checkpoint_restart_manual_linux.go'}, {'checkpoint_observation_default.go'}),
            './internal/testkit/checkpointrestart': ({'manual_linux.go'}, set()),
            './internal/testscope': (set(), set()),
            './sqlite': ({'checkpoint_restart_manual_linux_test.go'}, set()),
        }
        for path, data in packages.items():
            old = default[path]
            def selected_files(entry):
                return set().union(*(set(entry['package'].get(f, [])) for f in ('GoFiles', 'TestGoFiles', 'XTestGoFiles')))
            current_files, old_files = selected_files(data), selected_files(old)
            assert (current_files-old_files, old_files-current_files) == deltas[path], ('manual file delta', path)
            extra = {MODULE+'sqlite_test.'+root for root in MANUAL_ROOTS} if path == './sqlite' else set()
            assert set(data['roots']) == set(old['roots']) | extra, ('manual root delta', path)
    return {'target': key, 'goos': LISTS[key]['goos'], 'packages': packages, 'manual_executed': False}


def symbols(stdout):
    """Preserve the proven nm full-symbol-tail parser and exact root-set check."""
    selection = json.loads((OLD_E/'03_list_linux_manual.result.json').read_text())['selection']
    wanted = set(selection['packages']['./sqlite']['roots'])
    prefix = MODULE + 'sqlite'
    rootpattern = re.compile(re.escape(prefix)+r'(?:_test)?\.(?:Test|Fuzz|Example)[A-Za-z0-9_]*')
    names = []
    for line in stdout.splitlines():
        match = NM_ROW.fullmatch(line.lstrip(' \t'))
        assert match, ('malformed nm row', line)
        assert (match['address'] is None) == (match['type'] == 'U')
        names.append(match['symbol'])
    assert all(names.count(name) == 1 for name in wanted), 'missing or duplicate required symbols'
    actual = {name for name in names if rootpattern.fullmatch(name)}
    assert actual == wanted, ('root symbol difference', sorted(actual ^ wanted))
    manual_symbols = {prefix+'_test.'+root for root in MANUAL_ROOTS}
    assert {name for name in actual if '.TestManual' in name} == manual_symbols
    return {'required': len(wanted), 'exact_root_set': True, 'manual_symbols': sorted(manual_symbols),
        'image_sha256': sha(IMAGE), 'image_executed': False}


RUN_STARTED = False

def main():
    global RUN_STARTED
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-identity', type=Path, required=True)
    args = parser.parse_args()
    identity_path = args.source_identity.resolve()
    identity = json.loads(identity_path.read_text())
    assert identity['schema'] == 'checkpoint-focused-source-identity-v1'
    assert identity['format_manifest_sha256'] == MANIFEST_HASH
    assert re.fullmatch(r'[0-9a-f]{40}', identity['base_commit'])
    assert isinstance(identity['files'], dict) and identity['files']
    E.mkdir(exist_ok=False)
    RUN_STARTED = True
    with (R/'go-queue.lock').open('a+') as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert sha(GO) == GO_HASH and sha(FMT) == FMT_HASH
        assert sha(R/'run_misplaced_write_validation_v2.py') == HELPER_HASH
        assert sha(F/'FINAL-MANIFEST.json') == MANIFEST_HASH
        assert sha(F/'FINITE-PLANNED-TESTS.json') == PLAN_HASH
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == identity['base_commit']
        source = snapshot()
        assert {path: info['sha256'] for path, info in source.items()} == identity['files'], 'full source identity mismatch'
        assert all(source[path]['sha256'] == digest for path, digest in REQUIRED_SOURCES.items()), 'reviewed integration/pin mismatch'
        assert all(source[path]['sha256'] == digest for path, digest in HEALTHY_SOURCES.items()), 'healthy closure source drift'
        main_source = (W/'internal/testscope/main.go').read_text()
        assert all(main_source.count(hook) == 1 for hook in HOOKS), 'missing or duplicate direct checkpoint sourceguard hook'
        (R/'go-cache').mkdir(exist_ok=True)
        save('source-before.json', source)
        save('source-identity.json', identity)
        save('commands.json', [{'name': n, 'argv': a, 'cwd': str(W), 'environment': e} for n, a, e in COMMANDS])
        save('start.json', {'utc': now(), 'pid': os.getpid(), 'base_commit': identity['base_commit'],
            'source_identity_path': str(identity_path), 'source_identity_sha256': sha(identity_path),
            'source_manifest_sha256': sha(E/'source-before.json'), 'format_manifest_sha256': MANIFEST_HASH,
            'recorder_sha256': sha(Path(__file__).resolve()), 'tool_go_sha256': GO_HASH, 'tool_gofmt_sha256': FMT_HASH,
            'proven_helper_sha256': HELPER_HASH, 'direct_sourceguard_hooks': HOOKS, 'commands': len(COMMANDS),
            'scope': 'supplemental race: 3 existing healthy default roots only; new production no-op seams',
            'manual_image_executed': False, 'process_scope': 'one coordinated Go lease; no global process visibility claim'})
        finished = []
        for name, argv, env in COMMANDS:
            assert snapshot() == source, 'source changed before '+name
            start = now()
            initial = resources()
            save(name+'.resources-before.json', initial)
            assert initial['qualified'], 'resource admission '+name
            latched = False
            observer_error = None
            with (E/(name+'.stdout')).open('wb') as out, (E/(name+'.stderr')).open('wb') as err, (E/(name+'.resources.jsonl')).open('w') as samples:
                process = subprocess.Popen(argv, cwd=W, env=env, stdout=out, stderr=err)
                while True:
                    try:
                        sample = resources()
                        samples.write(json.dumps(sample)+'\n')
                        samples.flush()
                        latched |= not sample['qualified']
                    except Exception as error:
                        latched = True
                        observer_error = type(error).__name__+': '+str(error)
                        code = process.wait()  # Do not orphan or kill a running gate after observer failure.
                        break
                    code = process.poll()
                    if code is not None:
                        break
                    time.sleep(2)
            result = {'name': name, 'start_utc': start, 'end_utc': now(), 'exit_code': code,
                'resource_breach_latched': latched, 'observer_error': observer_error,
                'stdout_sha256': sha(E/(name+'.stdout')), 'stderr_sha256': sha(E/(name+'.stderr'))}
            save(name+'.result.json', result)
            assert snapshot() == source, 'source changed during '+name
            assert code == 0 and not latched, ('gate failed', result)
            stdout = (E/(name+'.stdout')).read_text()
            if name == '01_format':
                assert stdout == '', 'unformatted sources'
            elif name in LISTS:
                result['selection'] = selections(stdout, name)
            elif name in ROOT_GROUPS:
                selected = ROOT_GROUPS[name]
                result['tests'] = tests(stdout, list(selected))
                for package, expected in selected.items():
                    measured = result['tests'][MODULE+package[2:]]
                    assert set(measured['roots']) == set(expected), 'exact selector roots'
                result['evidence_kind'] = 'healthy_default_database' if name.startswith(('07_', '08_')) else 'pure_models' if name == '05_pure_models' else 'AST_source_contracts'
            elif name == '09_sourceguard':
                result['direct_checkpoint_hooks'] = HOOKS
            elif name == '10_compile_manual_sqlite':
                assert IMAGE.is_file()
                result.update(image_sha256=sha(IMAGE), image_executed=False)
            elif name == '11_nm_manual_sqlite':
                result['symbols'] = symbols(stdout)
                compiled = json.loads((E/'10_compile_manual_sqlite.result.json').read_text())
                assert compiled['image_sha256'] == result['symbols']['image_sha256'], 'compiled image changed'
            result['status'] = 'PASS'
            save(name+'.result.json', result)
            finished.append(result)
            print(json.dumps({'utc': now(), 'name': name, 'status': 'PASS'}), flush=True)
        save('completion.json', {'utc': now(), 'status': 'PASS', 'commands': finished,
            'source_unchanged': snapshot() == source, 'pure_model_roots': 0, 'AST_roots': 0,
            'healthy_default_roots': 3, 'healthy_evidence_separate_from_models': True,
            'manual_image_executed': False, 'manual_checkpoint_interruption_exit_recovery': 'NOT_RUN',
            'race': '3 healthy default roots', 'oracle_campaign': 'NOT_RUN', 'unrelated_tests': 'NOT_RERUN', 'reused_selection_evidence': str(OLD_E), 'rerun_reason': 'new default no-op observer calls affect the three existing healthy checkpoint paths; only these receive fresh race evidence; all preceding model/AST/list/compile evidence reused', 'lease': 'RELEASED_ON_RETURN'})
        fcntl.flock(lease, fcntl.LOCK_UN)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if RUN_STARTED:
            save('STOP.json', {'utc': now(), 'error_type': type(error).__name__, 'error': str(error),
                'remaining_commands': 'NOT_RUN', 'manual_image_executed': False})
        raise
