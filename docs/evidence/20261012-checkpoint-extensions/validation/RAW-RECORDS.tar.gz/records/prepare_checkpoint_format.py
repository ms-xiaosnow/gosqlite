from pathlib import Path
import hashlib,json,shutil,fcntl,subprocess,datetime,os,difflib
R=Path('/workspace/scratch/5e06a74e5f65/restart-20261012T2033');W=R/'gosqlite';E=R/'checkpoint-format'; B=E/'before';O=E/'overlay'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not E.exists(), 'Do not overwrite a formatting attempt'
assert sha((R/'checkpoint-extension-overlay/OVERLAY-MANIFEST.json').read_bytes())=='dd9e49ac002db6d2c57e0cadcc1e1fbdf94d8131ee4fc86c136db448d7523441'
assert sha((R/'checkpoint-guard-overlay/OVERLAY-MANIFEST.json').read_bytes())=='edaa9bac8613930b4cf0440a0ab9d3d0443864c904c4421739c0ef88d276cf60'
for p,h in [('checkpoint-extension-independent-review.md','23c8f2ce1273991d1ca95decdaddcdb924b0614be1a2c431ddefdafa7f811d14'),('checkpoint-guard-independent-review.md','846c309f404b0c7550483f44958e947a3d23cd59b90c8d97962af69f139da663')]:assert sha((R/p).read_bytes())==h,p
prior=json.loads((R/'misplaced-write-validation-v2/completion.json').read_text());assert prior['status']=='PASS' and prior['lease']=='RELEASED_ON_RETURN' and prior['utc']=='2026-10-12T23:04:54.335454+00:00'
tool=R/'toolchains/go1.27.2/bin/gofmt';assert sha(tool.read_bytes())=='5583dbb3339147fee7cdb067eb3cd4a50015b48c27084377f49d93833aa4ad77'
files={}
for group in ['checkpoint-extension','checkpoint-guard']:
 m=json.loads((R/(group+'-overlay')/'OVERLAY-MANIFEST.json').read_text())
 for d in m['files']:
  p=d['path'];b=(R/(group+'-overlay')/p).read_bytes();assert sha(b)==d['sha256'] and len(b)==d['bytes'];assert p not in files
  current=(W/p).read_bytes() if (W/p).is_file() else None;assert (sha(current) if current is not None else None)==d['baseline_sha256'],p
  for root in [B,O]:
   dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  files[p]={**d,'source_group':group,'w_before_sha256':sha(current) if current is not None else None}
(E/'initial-manifest.json').write_text(json.dumps({'files':files,'reviews':{'facility':'23c8f2ce1273991d1ca95decdaddcdb924b0614be1a2c431ddefdafa7f811d14','guard':'846c309f404b0c7550483f44958e947a3d23cd59b90c8d97962af69f139da663'},'status':'BEFORE_FORMAT'},indent=2)+'\n')
for p in ['checkpoint-extension-overlay/OVERLAY-MANIFEST.json','checkpoint-guard-overlay/OVERLAY-MANIFEST.json','checkpoint-extension-independent-review.md','checkpoint-guard-independent-review.md','checkpoint-guard-overlay/AFFECTED-ROOTS.json']:
 q=E/'evidence'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((R/p).read_bytes())
paths=sorted(p for p in files if p.endswith('.go'));assert len(paths)==23 and len(files)==24
(E/'go-files.txt').write_text(''.join(p+'\n' for p in paths))
(E/'w-status-before.txt').write_bytes(subprocess.check_output(['git','-C',str(W),'status','--short']))
(E/'processes-before-format.txt').write_bytes(subprocess.check_output(['ps','-eo','pid,ppid,lstart,args']))
with (R/'go-queue.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 resources={p:shutil.disk_usage(p)._asdict() for p in [str(W),'/tmp']};assert resources[str(W)]['free']>=2*2**30 and resources['/tmp']['free']>=2**30
 assert sha(tool.read_bytes())=='5583dbb3339147fee7cdb067eb3cd4a50015b48c27084377f49d93833aa4ad77'
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd=[str(tool),'-w',*[str(O/p) for p in paths]]
 (E/'gofmt-command.json').write_text(json.dumps({'argv':cmd,'cwd':str(E),'sha256':sha(tool.read_bytes()),'exclusive_lock':str(R/'go-queue.lock'),'prior_validation_end_utc':prior['utc'],'resources_before':resources,'start_utc':start},indent=2)+'\n')
 with (E/'gofmt.stdout').open('wb') as out,(E/'gofmt.stderr').open('wb') as err:p=subprocess.run(cmd,cwd=E,stdout=out,stderr=err,check=False)
 (E/'gofmt-result.json').write_text(json.dumps({'exit_code':p.returncode,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resources_after':{q:shutil.disk_usage(q)._asdict() for q in [str(W),'/tmp']},'no_compiler_test_native_execution':True},indent=2)+'\n');assert p.returncode==0
# Preserve formatter-only bytes independently of later literal synchronization.
for p in paths:
 q=E/'after-gofmt'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((O/p).read_bytes())
(E/'01-gofmt.diff').write_text(''.join(''.join(difflib.unified_diff((B/p).read_text().splitlines(True),(O/p).read_text().splitlines(True),'reviewed/'+p,'gofmt/'+p)) for p in paths))
print(json.dumps({'status':'GOFMT_COMPLETE','go_files':len(paths),'bytes_changed_files':sum((B/p).read_bytes()!=(O/p).read_bytes() for p in paths),'overlay':str(O),'gofmt_exit':p.returncode if False else 0}))
