from pathlib import Path
import re,json,hashlib
R=Path('/workspace/scratch/5e06a74e5f65/restart-20261012T2033');A=R/'checkpoint-extension-overlay';O=R/'checkpoint-guard-overlay';D=O/'internal/testscope'
m=json.loads((A/'OVERLAY-MANIFEST.json').read_text())
assert hashlib.sha256((A/'OVERLAY-MANIFEST.json').read_bytes()).hexdigest()=='e959f81438eb191934cb180cb065030d6f4a615fe516416f2c2c1ed4069f3545'
for x in m['files']:
 b=(A/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
paths=[x['path'] for x in m['files'] if x['path'].endswith('.go')]+['internal/testscope/main.go','internal/testscope/oracle_startup.go']
sources={p:((O/p) if (O/p).exists() else (A/p)).read_text() for p in paths}
imports={}
for p,s in sources.items():
 if p.startswith('internal/testscope/') or p in ('internal/pager/checkpoint.go','internal/pager/shared_checkpoint.go','internal/encstore/publish.go'):continue
 block=re.search(r'(?ms)^import \((.*?)^\)',s)
 values=re.findall(r'"([^"\n]+)"',block.group(1)) if block else re.findall(r'^import "([^"\n]+)"',s,re.M)
 imports[p]=' '.join(values)
s=(D/'checkpoint_restart.go').read_text();s=s[:s.index('var checkpointGuardImports =')]
s+='var checkpointGuardImports = map[string]string{\n'+''.join('\t'+json.dumps(p)+': '+json.dumps(v)+',\n' for p,v in imports.items())+'}\n\n'
s+='var checkpointGuardTemplates = map[string]string{\n'+''.join('\t'+json.dumps(p)+': '+json.dumps(v)+',\n' for p,v in sources.items())+'}\n'
(D/'checkpoint_restart.go').write_text(s)
# Explicit shared integrated-source freeze. The R5 owner must review these new
# neighbors and whole-main/oracle bytes before these three identities release.
p=D/'rekey_interruption.go';s=p.read_text()
for key,path in [('rekeyGuardPublish','internal/encstore/publish.go'),('rekeyGuardMain','internal/testscope/main.go'),('rekeyGuardOracle','internal/testscope/oracle_startup.go')]:
 pattern=rf'(?m)^(\s*{key}:\s*)"[a-f0-9]{{64}}",$'
 s,n=re.subn(pattern,lambda m:m.group(1)+'rekeyGuardHold,',s);assert n==1,(key,n)
 pattern=r'(?m)^\s*'+re.escape(json.dumps(path))+r':\s*"(?:[^"\\]|\\.)*",$'
 s,n=re.subn(pattern,lambda m:'\t'+json.dumps(path)+': '+json.dumps(sources[path])+',',s);assert n==1,(path,n)
p.write_text(s)
# Text-only mutant-anchor verification. No Go source parser/formatter is run.
t=(D/'checkpoint_restart_test.go').read_text()
consts=dict(re.findall(r'^const (checkpointGuard\w+) = "([^"\n]+)"',(D/'checkpoint_restart.go').read_text(),re.M))
anchors=re.findall(r'checkpointGuardMutant\(t, (checkpointGuard\w+),\s*`([^`]*)`,\s*(?:`([^`]*)`|"(?:[^"\\]|\\.)*")\)',t)
missing=[]
for key,old,new in anchors:
 if old not in sources[consts[key]]:missing.append((key,old))
print('FROZEN_GO_TEMPLATES',len(sources),'IMPORT_SETS',len(imports),'TEXT_MUTANT_ANCHORS',len(anchors),'MISSING',json.dumps(missing))
assert not missing
print('All new18 and changed3 R5 pins HOLD; no source executed.')
