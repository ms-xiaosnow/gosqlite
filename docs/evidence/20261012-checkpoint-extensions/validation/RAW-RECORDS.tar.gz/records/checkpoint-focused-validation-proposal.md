# R3/R4 focused validation proposal

Status: PREPARED ONLY / NOT_RUN. The recorder was written outside W and its Python syntax was parsed without importing or executing it. No Go, gofmt, Go compiler, Go test, Go AST scanner, native image, or database fixture was executed during this preparation. No W file was changed. Source remains frozen pending the lead's checkpoint authorization and integration.

## Recorder and admission

- Recorder: `run_checkpoint_focused_validation.py`
- Recorder SHA-256: `b1d4eaa2ef670d84c7193fc62d2c74c75c0d4ab1fe050682803068aa657b358e`
- Required final format manifest SHA-256: `112820790a2727e1b8d30f801ab0f7ae0fcb06e37e5f28a0c73d63ab1e7b2b94`
- Exact finite plan SHA-256: `9b3b31d013383605d4b0c2f584a3fc87cf3fde306f3b8d5f8571f832bac82921`
- Proven helper recorder SHA-256: `ddb2d3825e16d551783a4bb1f08b437d1eda14cef02a882f651323605bd6c27e`
- Output: `checkpoint-focused-validation/`, created once with `exist_ok=False`; an existing result is never overwritten or silently resumed.

Run only after integration and explicit authorization:

    python3 R/run_checkpoint_focused_validation.py --source-identity /absolute/path/to/SOURCE-IDENTITY.json

The source identity must be supplied explicitly after integration. There is no default identity path, guessed commit, or current-tree auto-admission. Required JSON fields:

    {
      "schema": "checkpoint-focused-source-identity-v1",
      "base_commit": "<actual current W HEAD, 40 lowercase hex characters>",
      "format_manifest_sha256": "112820790a2727e1b8d30f801ab0f7ae0fcb06e37e5f28a0c73d63ab1e7b2b94",
      "files": {"<every tracked or nonignored untracked relative W file>": "<SHA-256>"}
    }

The files mapping must equal the complete current `git ls-files --cached --others --exclude-standard -z` content-hash inventory, not just the 30 edited paths. The recorder also independently checks all 24 final-overlay paths, all six exact one-literal legacy main-pin results, and the three previously audited healthy test source files. Its finite before/after snapshots record lengths and Git-style executable modes and reject source changes between or during commands. It does not generate or guess a Git tree ID, alter the index, commit, publish, or integrate sources.

## Exactly 11 commands

1. `01_format`: fixed official gofmt `-l` over the 29 changed Go paths (23 overlay Go files and six literal-only legacy pin owners). Empty stdout required; this command does not rewrite files.
2. `02_list_linux_default`: `go list -json` with no tags across the five affected packages below. Records exact selected Go/Test/XTest files and Test/Fuzz/Example source-root inventories; requires default stubs and no native manual roots or positive manual gates.
3. `03_list_linux_manual`: the same packages under Linux with only `manual_checkpoint_restart`. Requires the exact four-file checkpoint capability selection and exact three sqlite manual roots. Verifies that Linux default/manual file and root deltas contain nothing else.
4. `04_list_nonlinux_fallback`: the same packages with `GOOS=darwin` and `manual_checkpoint_restart` still supplied. This list-only selection proves the `!linux` fallback stubs remain selected even when the manual tag is present; there is no cross-platform build or run.
5. `05_pure_models`: exactly the 12 pure checkpoint model/extension roots in `./internal/testkit/checkpointrestart`.
6. `06_ast_guards`: exactly 38 `./internal/testscope` roots, comprising the eight new checkpoint guards and the 30 specifically affected existing guards. These are AST/source-contract evidence.
7. `07_healthy_pager`: only `TestSharedWALSnapshotsPromotionAndCheckpoint` under ordinary Linux defaults.
8. `08_healthy_sqlite`: only `TestNativeWALConnectionLifecycle` and `TestReviewEncryptionSharedLatestCheckpointMetadata` under ordinary Linux defaults.
9. `09_sourceguard`: ordinary `go run ./internal/testscope`, with both direct checkpoint sourceguard hooks required in the pinned main source and recorded in evidence.
10. `10_compile_manual_sqlite`: one Linux `go test -c` for `./sqlite`, with only `manual_checkpoint_restart`, output outside W. The image is hashed but never launched.
11. `11_nm_manual_sqlite`: fixed official `go tool nm` on that image. Retains the proven complete-symbol-tail parser, requires every selected Test/Fuzz/Example root exactly once, rejects missing/additional/duplicate exact roots, and requires exactly the three manual root symbols below. The image must still match its compile hash.

Affected list packages: `./internal/pager`, `./internal/encstore`, `./internal/testkit/checkpointrestart`, `./internal/testscope`, `./sqlite`.

## Exact capability roles and default exclusions

Only the Linux manual selection adds:

- `internal/pager/checkpoint_restart_manual_linux.go`, replacing `checkpoint_observation_default.go`
- `internal/encstore/checkpoint_restart_manual_linux.go`, replacing `checkpoint_observation_default.go`
- `internal/testkit/checkpointrestart/manual_linux.go`
- `sqlite/checkpoint_restart_manual_linux_test.go`

Both Linux default and non-Linux fallback exclude all four files and every `TestManual*` root. Pager's `rollback_io_default.go` and encstore's `rekey_observation_default.go` stay selected in all three list modes. The recorder rejects every selected positive manual capability tag other than the sole checkpoint tag in its Linux manual list. Prior rollback/recovery, rekey, readonly-WAL, encrypted-root, encryption-upgrade, WAL-publication, namespace and Darwin-inventory manual capabilities remain excluded. Untagged source-contract tests such as `readonly_wal_manual_contract_test.go` are ordinary source guards and are not mistaken for native manual capabilities.

The three permitted compile-only sqlite symbols are:

- `github.com/ms-xiaosnow/gosqlite/sqlite_test.TestManualCheckpointRestartController`
- `github.com/ms-xiaosnow/gosqlite/sqlite_test.TestManualCheckpointRestartWriter`
- `github.com/ms-xiaosnow/gosqlite/sqlite_test.TestManualCheckpointRestartProbe`

The two required direct sourceguard hooks are:

- `inspectCheckpointRestartSource(path, raw)` in the ordinary file walk
- `inspectCheckpointRestartContracts(".")` in the ordinary contract pass

## Healthy evidence remains separate

The existing `healthy-default-closure-audit.json` covers all three selected roots and all seven no-op seams. Their source hashes are fixed in the recorder. Their bodies were also read during preparation: pager uses successful ordinary shared commits and busy-reader observations; sqlite WAL lifecycle includes a successful exclusive public checkpoint and healthy retained-WAL reopen; encrypted shared metadata performs an ordinary refreshed-head checkpoint and checks latest geometry and zero WAL segments. These are ordinary healthy database tests, not pure model evidence. No damaged fixture, injected I/O failure, forced process exit, manual interruption, or recovery replay is selected. A healthy reopen is not claimed as crash/recovery evidence.

## Common execution and stopping rules

The fixed official Go/gofmt paths, exact hashes, clean environment, resource sampler/latch, JSON root parser, and nm full-tail parser derive from `run_misplaced_write_validation_v2.py`. `GOMAXPROCS=2`, `CGO_ENABLED=0`, `GOOS=linux` except the explicit list-only fallback, `GOARCH=amd64`, `GOFLAGS=''`, `GOTOOLCHAIN=local`, network module resolution off, and `-p=1 -buildvcs=false -mod=readonly` apply where supported. Tests use `-json -vet=off -count=1 -parallel=1 -timeout=0` and fully anchored exact-root selectors. No race run, oracle invocation, campaign, broad test suite, fuzz execution, benchmark, hidden selector, native target run, or `-run=^$` substitute is present.

One nonblocking exclusive `go-queue.lock` lease covers the entire run. Resource admission and latched observations use the proven 2 GiB workspace / 1 GiB `/tmp` free-space floors and at least 10,000 free inodes per filesystem. On a gate failure or observer breach, the recorder preserves that result and writes STOP; all remaining commands stay NOT_RUN. It never kills or orphans a live gate after an observer failure and never retries a failed command. No open-ended inventory polling is added.

This proposal does not authorize execution. It does not repeat already-passed R2/R5 validation. A final PASS, if later established, is limited to these 11 commands; checkpoint interruption, forced exit, restart recovery and physical campaign results remain NOT_RUN.

## Exact selected pure-model roots

- `TestCheckpointRestartTenCases`
- `TestCheckpointRestartAuthorityCuts`
- `TestCheckpointRestartCommittedHeadCausality`
- `TestCheckpointRestartTransportBinding`
- `TestCheckpointRestartOwnerWaitAndUnknown`
- `TestCheckpointRestartPrivateFamilyCopies`
- `TestCheckpointRestartEncryptedSameEpoch`
- `TestCheckpointRestartNeverPhysicalPass`
- `TestCheckpointExtensionFixtureRows`
- `TestCheckpointExtensionGramsLedger`
- `TestCheckpointExtensionGraphMembershipLedger`
- `TestCheckpointExtensionQueryPathsAndCheck`

## Exact selected AST/source-contract roots

- `TestCheckpointRestartGuardInventoryAndGate`
- `TestCheckpointRestartGuardProductionOrder`
- `TestCheckpointRestartGuardObserverPurpose`
- `TestCheckpointRestartGuardPublicEntryAndCommitReceipt`
- `TestCheckpointRestartGuardProcessOwnership`
- `TestCheckpointRestartGuardFullExtensionLedger`
- `TestCheckpointRestartGuardPrivateCopiesAndProbe`
- `TestCheckpointRestartGuardDefaultAndIntegration`
- `TestRekeyGuardInventoryGate`
- `TestRekeyGuardPublicationOrder`
- `TestRekeyGuardObserverIsolation`
- `TestRekeyGuardPublicReturnACK`
- `TestRekeyGuardProcessOwnership`
- `TestRekeyGuardProbeLedger`
- `TestRekeyGuardIntegrationDefault`
- `TestReadOnlyWALManualSourceContract`
- `TestReadOnlyWALManualDefaultExclusion`
- `TestReadOnlyWALManualWholeRootInventory`
- `TestReadOnlyWALManualGateAndProfileMutations`
- `TestReadOnlyWALManualEffectBoundaryMutations`
- `TestReadOnlyWALManualOwnershipMutations`
- `TestReadOnlyWALManualPureClosureMutations`
- `TestOracleSourceConstructorGuard`
- `TestOracleSourceImportAndMutationGuard`
- `TestOracleSourceFactoryLiteralGuard`
- `TestOracleSourceNativeExceptionGuard`
- `TestOracleSourcePathScope`
- `TestScopeSourceReferenceGuard`
- `TestEncryptedRootFiniteStructure`
- `TestEncryptedRootFalsePassSourcesEvenWhenRepinned`
- `TestEncryptedRootWholeSourceAndCapabilityBoundary`
- `TestEncryptedRootPinsRequireIndependentRelease`
- `TestFormatUpgradeMainKeepsExistingPolicies`
- `TestWALPublicationGuardFixedSourceAndWiring`
- `TestRollbackFaultGuardWiringPreservesPriorPolicies`
- `TestRollbackFaultSQLWiringAndMainReviewHold`
- `TestRollbackRestartWiringPreservesAllPoliciesAndReviewHold`
- `TestRollbackRestartOracleExceptionRequiresCompletePinnedNativeClosure`
