from pathlib import Path
R=Path('/workspace/scratch/5e06a74e5f65/restart-20261012T2033'); W=R/'gosqlite'; O=R/'checkpoint-guard-overlay'
def read(n):return (W/'internal/testscope'/n).read_text()
def save(n,s):(O/'internal/testscope'/n).write_text(s)
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
s=read('main.go')
s=replace(s,'\t\trekey, rekeyErr := inspectRekeyInterruptionSource(path, raw)', '''\t\tcheckpoint, checkpointErr := inspectCheckpointRestartSource(path, raw)
\t\tif checkpointErr != nil {
\t\t\treturn checkpointErr
\t\t}
\t\tfindings = append(findings, checkpoint...)
\t\trekey, rekeyErr := inspectRekeyInterruptionSource(path, raw)''')
s=replace(s,'\tif failed {\n\t\tos.Exit(1)\n\t}', '''\tcheckpointContracts, checkpointContractErr := inspectCheckpointRestartContracts(".")
\tif checkpointContractErr != nil {
\t\tfmt.Fprintln(os.Stderr, checkpointContractErr)
\t\tfailed = true
\t}
\tfor _, finding := range checkpointContracts {
\t\tfmt.Fprintln(os.Stderr, finding)
\t\tfailed = true
\t}
\tif failed {
\t\tos.Exit(1)
\t}''');save('main.go',s)
s=read('oracle_startup.go');s=replace(s,'|| rekeyGuardProcessReference(path, sel, parents, set, raw) {','|| rekeyGuardProcessReference(path, sel, parents, set, raw) || checkpointGuardProcessReference(path, sel, parents, set, raw) {');save('oracle_startup.go',s)
s=read('readonly_wal_manual.go')
s=replace(s,'\trekey := readOnlyWALManualSequence(walkBody,', '''\tcheckpoint := readOnlyWALManualSequence(walkBody, `checkpoint, checkpointErr := inspectCheckpointRestartSource(path,raw)`, `if checkpointErr != nil { return checkpointErr }`, `findings = append(findings,checkpoint...)`)
\tif checkpoint < 0 {
\t\treport("checkpoint restart source")
\t}
\trekey := readOnlyWALManualSequence(walkBody,''')
s=replace(s,'if rekey < 0 || rootNegative <= rekey','if checkpoint < 0 || rekey <= checkpoint || rootNegative <= rekey')
s=replace(s,'{"inspectRekeyInterruptionContracts", "rekeyContracts", "rekeyContractErr"},','{"inspectRekeyInterruptionContracts", "rekeyContracts", "rekeyContractErr"},\n\t\t{"inspectCheckpointRestartContracts", "checkpointContracts", "checkpointContractErr"},')
s=replace(s,'\t\t"findings=append(findings,rekey...)":','\t\t"findings=append(findings,checkpoint...)": 0,\n\t\t"findings=append(findings,rekey...)":')
s=replace(s,'[]string{"inspectRekeyInterruptionSource(path,raw)",','[]string{"inspectCheckpointRestartSource(path,raw)", "inspectRekeyInterruptionSource(path,raw)",')
s=replace(s,'`inspectRekeyInterruptionContracts(".")`}','`inspectRekeyInterruptionContracts(".")`, `inspectCheckpointRestartContracts(".")`}');save('readonly_wal_manual.go',s)
s=read('readonly_wal_manual_test.go');s=s.replace('// Fourteen rekey/encrypted-root/combined/SQL/restart/recovery hooks, fourteen inert counterexamples each. Keep the old','// Sixteen checkpoint/rekey/encrypted-root/combined/SQL/restart/recovery hooks, fourteen inert counterexamples each. Keep the old')
anchor='\t\t{\n\t\t\tassignment:  `rekey, rekeyErr := inspectRekeyInterruptionSource(path, raw)`,'
new='''\t\t{
\t\t\tassignment: `checkpoint, checkpointErr := inspectCheckpointRestartSource(path, raw)`,
\t\t\thelper: "inspectCheckpointRestartSource",
\t\t\tresult: `findings = append(findings, checkpoint...)`,
\t\t\tresultName: "checkpoint",
\t\t\terrorBlock: "if checkpointErr != nil {\\n\\t\\t\\treturn checkpointErr\\n\\t\\t}",
\t\t\terrorName: "checkpointErr",
\t\t\terrorReport: `return checkpointErr`,
\t\t\tmoveBefore: `for _, f := range findings {`,
\t\t\tstate: "findings",
\t\t},
\t\t{
\t\t\tassignment: `checkpointContracts, checkpointContractErr := inspectCheckpointRestartContracts(".")`,
\t\t\thelper: "inspectCheckpointRestartContracts",
\t\t\tresult: "for _, finding := range checkpointContracts {\\n\\t\\tfmt.Fprintln(os.Stderr, finding)\\n\\t\\tfailed = true\\n\\t}",
\t\t\tresultName: "checkpointContracts",
\t\t\terrorBlock: "if checkpointContractErr != nil {\\n\\t\\tfmt.Fprintln(os.Stderr, checkpointContractErr)\\n\\t\\tfailed = true\\n\\t}",
\t\t\terrorName: "checkpointContractErr",
\t\t\terrorReport: `fmt.Fprintln(os.Stderr, checkpointContractErr)`,
\t\t\tmoveBefore: `contracts, err := inspectOracleContracts(".")`,
\t\t\tstate: "failed",
\t\t},
'''+anchor
s=replace(s,anchor,new);s=replace(s,'len(cases) != 14 || checked != 196','len(cases) != 16 || checked != 224');save('readonly_wal_manual_test.go',s)
s=read('rekey_interruption.go')
# Limit edits to active function implementation, not embedded source fixtures.
a=s.index('func rekeyGuardPublication(');b=s.index('\nfunc rekeyGuardObserver(',a)
part=s[a:b]
for point in ('BeforeRootRename','AfterRootRename','AfterRootDirSync'):
 line=f'`rekeyPublicationObserve(ctx, rekey{point}, s.path, s.rootBytes, raw)`, '
 # Text has a newline, not a trailing space.
 old=f'`rekeyPublicationObserve(ctx, rekey{point}, s.path, s.rootBytes, raw)`,\n'
 part=replace(part,old,old+f'\t\t`checkpointPublicationObserve(ctx, checkpoint{point}, s.path, s.rootBytes, raw)`,\n')
s=s[:a]+part+s[b:]
# Original R5 scope, call counts, observer bodies and six-case contract remain.
save('rekey_interruption.go',s)
s=read('rekey_interruption_test.go');anchor='func TestRekeyGuardPublicationOrder(t *testing.T) {\n'
s=replace(s,anchor,anchor+'''\t// The exact checkpoint neighbors are inert for R5's own purpose. Their
\t// placement is admitted explicitly; no general observer whitelist exists.
\trekeyGuardMutant(t, rekeyGuardPublish,
\t\t`checkpointPublicationObserve(ctx, checkpointBeforeRootRename, s.path, s.rootBytes, raw)`,
\t\t`checkpointPublicationObserve(ctx, checkpointAfterRootRename, s.path, s.rootBytes, raw)`)
\trekeyGuardMutant(t, rekeyGuardPublish,
\t\t`checkpointPublicationObserve(ctx, checkpointAfterRootRename, s.path, s.rootBytes, raw)`, "")
''');save('rekey_interruption_test.go',s)
print('W untouched; six integration files written; shared R5 identity release remains pending.')
